-- TABLE ta_g3p_etablissement_facturant
INSERT INTO ta_securite (`habilitation`,`table`,`consultation`,`creation`,`modification`,`suppression`,`notification`)
VALUES('ADMIN','ta_g3p_etablissement_facturant','1','1','1','1','1');

-- TABLE ta_g3p_type_uo
INSERT INTO ta_securite (`habilitation`,`table`,`consultation`,`creation`,`modification`,`suppression`,`notification`)
VALUES('ADMIN','ta_g3p_type_uo','1','1','1','1','1');

-- TABLE ta_g3p_version_prix
INSERT INTO ta_securite (`habilitation`,`table`,`consultation`,`creation`,`modification`,`suppression`,`notification`)
VALUES('ADMIN','ta_g3p_version_prix','1','1','1','1','1');


-- TABLE ta_g3p_prestation
INSERT INTO ta_securite (`habilitation`,`table`,`consultation`,`creation`,`modification`,`suppression`,`notification`)
VALUES('ADMIN','ta_g3p_prestation','1','1','1','1','1');


-- TABLE ta_g3p_grille_prix_prestation
INSERT INTO ta_securite (`habilitation`,`table`,`consultation`,`creation`,`modification`,`suppression`,`notification`)
VALUES('ADMIN','ta_g3p_grille_prix_prestation','1','1','1','1','1');












