-- TABLE ta_g3p_etablissement_facturant
INSERT INTO `ta_libelle_colonne_table` (`cod_colonne`,`lib_colonne`) VALUES ('C0EFAC','CODE ETABLISSEMENT');
INSERT INTO `ta_libelle_colonne_table` (`cod_colonne`,`lib_colonne`) VALUES ('LBEFAC','LIBELLE ETABLISSEMENT FACTURANT');

-- TABLE ta_g3p_type_uo
INSERT INTO `ta_libelle_colonne_table` (`cod_colonne`,`lib_colonne`) VALUES ('C0TYUO','CODE TYPE UO');
INSERT INTO `ta_libelle_colonne_table` (`cod_colonne`,`lib_colonne`) VALUES ('LBTYUO','LiBELLE TYPE UO');

-- TABLE ta_g3p_version_prix
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('C0TYPR','CODE TYPE PRIX');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('LBTYPR','LIBELLE TYPE PRIX');

-- TABLE ta_g3p_prestation
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('C0PRE','CODE PRESTATION');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('LBPRE','LIBELLE PRESTATION');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('NATPRE','NATURE  PRESTATION');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('CHAPRE','CHAPITRE PRESTATION');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('TYUO','TYPE UO');

-- TABLE ta_g3p_grille_prix_prestation
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('C0VEPR','TYPE CODE VERSION PRIX');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('ANNEE','ANNEE');
INSERT INTO ta_libelle_colonne_table (`cod_colonne`,`lib_colonne`) VALUES ('PRIX','PRIX');
