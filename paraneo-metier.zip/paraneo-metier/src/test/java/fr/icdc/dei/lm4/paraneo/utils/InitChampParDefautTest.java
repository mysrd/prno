package fr.icdc.dei.lm4.paraneo.utils;


import org.junit.Test;
import static org.junit.Assert.*;


import fr.icdc.dei.lm4.paraneo.entite.transverse.TaDeviseLmtay502;

public class InitChampParDefautTest {

	@Test
	public void testInitialiser() throws Exception {
		InitChampParDefaut classeAtester = new InitChampParDefaut();
		TaDeviseLmtay502 lmtay502ATester = new TaDeviseLmtay502();
		classeAtester.initialiser(lmtay502ATester, "Toto");

		assertEquals(new Integer(0), lmtay502ATester.getYnqco0());
		assertEquals(new Integer(0), lmtay502ATester.getCbcalt());
		assertEquals(new Integer(0), lmtay502ATester.getYerpa());
	}

}
