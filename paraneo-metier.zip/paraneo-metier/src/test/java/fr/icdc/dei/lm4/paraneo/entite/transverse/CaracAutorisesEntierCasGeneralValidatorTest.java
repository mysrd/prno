package fr.icdc.dei.lm4.paraneo.entite.transverse;

import static org.junit.Assert.*;

import java.lang.annotation.Annotation;

import javax.validation.Payload;

import org.junit.Test;

public class CaracAutorisesEntierCasGeneralValidatorTest {

	private void initTestDecimal(CaracAutorisesEntierCasGeneralValidator validator) {
		CaracAutorisesEntierCasGeneral annotation = new CaracAutorisesEntierCasGeneral() {

			@Override
			public Class<? extends Annotation> annotationType() {
				return null;
			}

			@Override
			public Class<? extends Payload>[] payload() {
				return null;
			}

			@Override
			public int nbCarac() {			// La zone saisie doit obligatoirement contenir 3 caractères
				return 3;
			}

			@Override
			public String message() {
				return null;
			}

			@Override
			public Class<?>[] groups() {
				return null;
			}
		};
		validator.initialize(annotation);
	}

	@Test
	public void test() {
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("1234", null));
	}

	@Test
	public void test2(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(true, validator.isValid("123", null));

	}

	@Test
	public void test3(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("12", null));
	}

	@Test
	public void test4(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("A", null));
	}

	@Test
	public void test5(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("1.2", null));
	}

	@Test
	public void test6(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("1 2", null));
	}

	@Test
	public void test7(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid("12 ", null));
	}

	@Test
	public void test8(){
		CaracAutorisesEntierCasGeneralValidator validator = new CaracAutorisesEntierCasGeneralValidator();
		initTestDecimal(validator);
		assertEquals(false, validator.isValid(" 12", null));
	}

}
