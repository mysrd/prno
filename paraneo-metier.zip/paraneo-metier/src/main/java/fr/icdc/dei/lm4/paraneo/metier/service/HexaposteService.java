package fr.icdc.dei.lm4.paraneo.metier.service;

import java.io.InputStream;

import fr.icdc.dei.lm4.paraneo.entite.transverse.LigneHexaposte;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodePostal;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

public interface HexaposteService {
		
	public byte[] lancerTraitementHexaposte(InputStream fichierHexaposte, String nomUtilisateur) throws BusinessServiceException;

	public LigneHexaposte decomposerLigneHexaposte(String ligne);
	
	public boolean comparerLigneFichierEtEnregistrementTable(LigneHexaposte ligneFichier, TaCodePostal enregistrementTable);
	
	public TaCodePostal copierLigneFichierDansEnregistrementTablePourCreation(LigneHexaposte ligneFichier, TaCodePostal enregistrement);
	
	public TaCodePostal copierLigneFichierDansEnregistrementTablePourModification(LigneHexaposte ligneFichier, TaCodePostal enregistrement);
	
	public void envoyerNotificationsDido();
	
	public boolean hasNombreDeLignesSuffisant(InputStream fluxFichier) throws BusinessServiceException;

}
