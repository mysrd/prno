package fr.icdc.dei.edt.metier.service.impl;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.edt.core.Auditable;
import fr.icdc.dei.edt.core.converter.ConverterException;
import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.recherche.Condition;
import fr.icdc.dei.edt.metier.service.ExportBusinessService;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.edt.persistance.service.GenericPersistenceService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.ChampCalculeService;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesInputAjax;
import fr.icdc.dei.lm4.paraneo.utils.DatatablesOutputAjax;
import fr.icdc.dei.lm4.paraneo.utils.HDIVWrapper;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;
import fr.icdc.dei.lm4.paraneo.utils.RoueCranteeUtil;

/**
 * Implémentation du service métier ReferentielBusinessService.
 *
 * @author abdennebi
 *
 */
@Service("editTablesBusinessService")
public class ReferentielBusinessServiceImpl extends AbstractBusinessService implements ReferentielBusinessService {

	private static final Logger LOGGER = Logger.getLogger(ReferentielBusinessServiceImpl.class);

	@Autowired
	private ExportBusinessService exportBS;

	@Autowired
	private RoueCranteeUtil roueCranteeUtil;
	
	@Resource(name = "editTablesPersistanceService")
	private GenericPersistenceService referentielPS;

	@Resource(name="champCalculeService")
	private ChampCalculeService champCalculeService;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<TableDescription> getTableList() throws BusinessServiceException {
		LOGGER.info("ACCES AUX TABLES");
		List<TableDescription> tableList = null;

		try {
			tableList = referentielPS.selectListTables();
		} catch (BusinessServiceException pse) {
			throw new BusinessServiceException(pse);
		}
		return tableList;
	}

	@Transactional
	public Object findById(Class<?> clazz, Serializable id) throws BusinessServiceException {
		Object obj = null;
		obj = referentielPS.findById(clazz, id);
		return obj;
	}

	@Transactional
	public List<Object> findAll(String className) throws BusinessServiceException {
		return referentielPS.findAll(className);
	}

	@Transactional
	public List<Object> findAll(String className, List<Condition> conditions) throws BusinessServiceException {
		return referentielPS.findAll(className, conditions);
	}

	@Transactional
	public void create(Object obj) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
	IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		referentielPS.create(obj);
	}

	@Transactional
	public void create(Object obj, TableDescription table) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
			IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		// Si l'entité est de type Auditable, on lui injecte le principal
		// afin que cette information soit exploitée par les intercepteurs
		// Hibernate
		if (obj instanceof Auditable) {
			Auditable auditable = (Auditable) obj;
			UserDetails principal = this.getPrincipal();
			auditable.setPrincipal(principal);
		}
		referentielPS.create(obj);
		logCreer(obj, table);
	}

	@Transactional
	public void update(Object newValue, Object oldObject, TableDescription table) throws BusinessServiceException, ConverterException,
			IllegalArgumentException, SecurityException, IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (newValue instanceof Auditable) {
			Auditable auditable = (Auditable) newValue;
			UserDetails principal = this.getPrincipal();
			auditable.setPrincipal(principal);
		}
		referentielPS.update(newValue);

		logModifier(newValue, oldObject, table);

	}

	@Transactional
	/**
	 * Mise a jour simple d'un enregistrement sans log
	 * @param newValue
	 * @throws BusinessServiceException
	 */
	public void update(Object newValue) throws BusinessServiceException{
		referentielPS.update(newValue);
	}

	@Transactional
	public void delete(Object obj, TableDescription table) throws BusinessServiceException, ConverterException, IllegalArgumentException, SecurityException,
			IntrospectionException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		// Si l'entité est de type Auditable, on lui injecte le principal
		// afin que cette information soit exploitée par les intercepteurs
		// Hibernate
		if (obj instanceof Auditable) {
			Auditable auditable = (Auditable) obj;
			UserDetails principal = this.getPrincipal();
			auditable.setPrincipal(principal);
		}

		referentielPS.delete(obj);
		logSupprimer(obj, table);

	}

	@Transactional
	@Override
	public int count(String className) throws BusinessServiceException {
		try {
			Class<?> clazz = Class.forName(className);
			return referentielPS.count(clazz);
		} catch (ClassNotFoundException cnfe) {
			throw new BusinessServiceException(cnfe);
		} catch (Exception e) {
			throw new BusinessServiceException(
					"ReferentielBusinessServiceImpl", "count", e);
		}
	}

	/*
	 * public int countForConditions(String className, List<Condition>
	 * conditions) throws BusinessServiceException { try { Class<?> clazz =
	 * Class.forName(className); return referentielPS.countForConditions(clazz,
	 * conditions); } catch (ClassNotFoundException cnfe) { throw new
	 * BusinessServiceException(cnfe); }/* catch (Exception e) { throw new
	 * BusinessServiceException("ReferentielBusinessServiceImpl",
	 * "countForConditions", e); } / }
	 */

	@Transactional
	public List<Object> findAll(String className, int firstResult, int maxResults) throws BusinessServiceException {
		List<Object> enregistrements = null;
		Class<?> clazz;
		try {
			clazz = Class.forName(className);
		} catch (ClassNotFoundException e) {
			throw new BusinessServiceException(e);
		}
		enregistrements = referentielPS.findAll(clazz, firstResult, maxResults);
		return enregistrements;
	}

	/*
	 * public List<Object> search(String className, List<Condition> conditions,
	 * int firstResult, int maxResults, List<OrderBy> orderByList) throws
	 * BusinessServiceException { List<Object> enregistrements = null; Class<?>
	 * clazz; try { clazz = Class.forName(className); } catch
	 * (ClassNotFoundException e) { throw new BusinessServiceException(e); }
	 * enregistrements = referentielPS.findAll(clazz, conditions, firstResult,
	 * maxResults, orderByList); return enregistrements; }
	 */

	private void logCreer(Object newObject, TableDescription table) throws ConverterException, IntrospectionException, IllegalArgumentException,
			IllegalAccessException, InvocationTargetException, SecurityException, NoSuchMethodException {
		UserDetails tPrincipal = this.getPrincipal();
		StringBuffer valuePisteBuffer = new StringBuffer();
		for (ColumnDescription colonne : table.getColumnList()) {
			String key = colonne.getPropertyName();
			Object value = null;
			Method getter = new PropertyDescriptor(key, newObject.getClass()).getReadMethod();
			value = getter.invoke(newObject);
			if (colonne.isForeignKey() && value != null) {
				Method toString = value.getClass().getMethod("toString");
				value = toString.invoke(value);
			}
			valuePisteBuffer.append("[" + key + "=" + value + "]");
		}

		StringBuffer piste = new StringBuffer("[Table : " + table.getTableName() + "][Operation : Création][Utilisateur : " + tPrincipal.getUsername() + "]\n");
		piste.append("VALUE : ");
		piste.append(valuePisteBuffer);
		piste.append("\n");
		log(piste);
	}

	private void logModifier(Object newObject, Object oldObject, TableDescription table) throws ConverterException, IntrospectionException,
			IllegalArgumentException, IllegalAccessException, InvocationTargetException, SecurityException, NoSuchMethodException {
		UserDetails tPrincipal = this.getPrincipal();
		StringBuffer newValuePisteBuffer = new StringBuffer();
		StringBuffer oldValuePisteBuffer = new StringBuffer();
		for (ColumnDescription colonne : table.getColumnList()) {
			String key = colonne.getPropertyName();
			Object newValue;
			Object oldValue;
			Method getter = new PropertyDescriptor(key, newObject.getClass()).getReadMethod();
			newValue = getter.invoke(newObject);
			oldValue = getter.invoke(oldObject);
			if (colonne.isForeignKey() && newValue != null) {
				Method toString = newValue.getClass().getMethod("toString");
				newValue = toString.invoke(newValue);
			}
			if (colonne.isForeignKey() && oldValue != null) {
				Method toString = oldValue.getClass().getMethod("toString");
				oldValue = toString.invoke(oldValue);
			}
			newValuePisteBuffer.append("[" + key + "=" + newValue + "]");
			oldValuePisteBuffer.append("[" + key + "=" + oldValue + "]");
			if ((oldValue != null && !oldValue.equals(newValue)) || (oldValue == null && newValue != null)) {
				newValuePisteBuffer.append("* ");
				oldValuePisteBuffer.append("* ");
			}
		}

		StringBuffer piste = new StringBuffer("[Table : " + table.getTableName() + "][Operation : Modification][Utilisateur=" + tPrincipal.getUsername()
				+ "]\n");
		piste.append("OLD VALUE : ");
		piste.append(oldValuePisteBuffer);
		piste.append("\nNEW VALUE : ");
		piste.append(newValuePisteBuffer);
		piste.append("\n");
		log(piste);
	}

	private void logSupprimer(Object newObject, TableDescription table) throws ConverterException, IntrospectionException, IllegalArgumentException,
			IllegalAccessException, InvocationTargetException, SecurityException, NoSuchMethodException {
		UserDetails tPrincipal = this.getPrincipal();

		StringBuffer valuePisteBuffer = new StringBuffer();

		for (ColumnDescription colonne : table.getColumnList()) {
			String key = colonne.getPropertyName();
			Object value = null;
			Method getter = new PropertyDescriptor(key, newObject.getClass()).getReadMethod();
			value = getter.invoke(newObject);
			if (colonne.isForeignKey() && value != null) {
				Method toString = value.getClass().getMethod("toString");
				value = toString.invoke(value);
			}
			valuePisteBuffer.append("[" + key + "=" + value + "]");
		}

		StringBuffer piste = new StringBuffer("[Table : " + table.getTableName() + "][Operation : Suppression][Utilisateur = " + tPrincipal.getUsername()
				+ "]\n");
		piste.append("VALUE : ");
		piste.append(valuePisteBuffer);
		piste.append("\n");
		log(piste);
	}

	private void log(StringBuffer piste) {
		Date dateModification = new Date();
		LOGGER.info(dateModification.toString() + piste.toString());
	}

	@Override
	@Transactional
	public List<String> getColumnsOrder(TableDescription table) {

		return referentielPS.getColumnsOrder(table.getTableName());
	}

	@Transactional
	public List<TaLibelleColonneTable> getAllLibelleColonneTable() throws BusinessServiceException {
		List<TaLibelleColonneTable> colonneListe = null;
		colonneListe = referentielPS.getAllLibelleColonneTable();
		return colonneListe;
	}

	@Override
	@Transactional
	public Object findByMultiCriteria(Class<?> classeEntite,List<String> clefsPrimaire, List<Object> valeurs) {
		return referentielPS.findByMultiCriteria(classeEntite,clefsPrimaire,valeurs);
	}

	@Override
	@Transactional		// Les requêtes de la méthode s'exécuteront dans une transaction
	public boolean verifUniciteJourFerieLegal(Date dateRecherchee) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteJourFerieLegal(dateRecherchee);
	}

	@Override
	@Transactional
	public boolean verifUniciteJourFerieLegal602(String nomTableTestee, Date dateRecherchee) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteJourFerieLegal602(nomTableTestee, dateRecherchee);
	}

	@Override
	@Transactional
	public boolean verifUniciteCodePays501(String cpay, String valeurDuChamp, String nomChamp) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteCodePays501(cpay, valeurDuChamp, nomChamp);
	}

	@Override
	@Transactional
	public boolean verifUniciteCodeDeviseIsoNum502(String cdev, String valeurDuChamp) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteCodeDeviseIsoNum502(cdev, valeurDuChamp);
	}

	@Override
	@Transactional
	public boolean verifUniciteCoupleCodesBureauEtService(String cung, String cburo, String cdserv) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteCoupleCodesBureauEtService(cung, cburo, cdserv);
	}

	@Override
	@Transactional
	public boolean verifUniciteCodePole(String cung, String cpole) {
		// TODO Auto-generated method stub
		return referentielPS.verifUniciteCodePole(cung, cpole);
	}

	// Strictement superieur a cette valeur on active le depliant
	private static final int NOMBRE_COLONNE_DEPLIANT = 5;
	@Override
	@Transactional
	public DatatablesOutputAjax  requeteDatatables(Integer draw, Integer start,Integer length, DatatablesInputAjax parametresStructures, String table, List<String> tablesEnModification, List<String> tablesEnSuppression, HDIVWrapper hdivWrapper, List<Object> objetsTableAAficcher ) throws BusinessServiceException {
		List<Object> enregistrementsBruts = this.referentielPS.requeteDatatables(draw, start, length, parametresStructures,table);
		LOGGER.debug("Fin lancement requête");
		DatatablesOutputAjax datatablesOutputAjax = new DatatablesOutputAjax();
		datatablesOutputAjax.setEnregistrementsBruts(enregistrementsBruts);
		List<Collection<Object>> listeSansClefs = new ArrayList<>();

		List<TableDescription> listeTables = this.getTableList();
		TableDescription descriptionTable = IntrospectionUtils.getTableDescriptionFromTableName(listeTables, table);


		List<Map<String, Object>> objetsAAfficher = new ArrayList<Map<String, Object>>();
		for (Object enregistrementBrut : enregistrementsBruts) {
			objetsAAfficher.add(this.construireMapObjet(descriptionTable, enregistrementBrut));
			champCalculeService.calculerValeurChamps(enregistrementBrut);
		}

		int compteur = 0;
		for (Map<String, Object> list : objetsAAfficher) {
			
			List<Object> valeursModifiees = new ArrayList<Object>();
			if(descriptionTable.getColumnList().size()>NOMBRE_COLONNE_DEPLIANT && !"ta_code_postal".equals(descriptionTable.getTableName())){
				valeursModifiees.add("<span class=\"openDescr\">Plus d'informations</span>");
			}
			IntrospectionUtils.reorderColumns(descriptionTable, this.getColumnsOrder(descriptionTable));
			for (ColumnDescription column : descriptionTable.getColumnList()) {
				Object valeur = list.get(column.getColumnName());
				if(valeur==null){
					valeursModifiees.add("");
				} else if(valeur instanceof Date){
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					valeursModifiees.add(sdf.format(valeur));
				} else if(valeur instanceof BigDecimal) {
					valeursModifiees.add(((BigDecimal) valeur).toPlainString());
				} else if(valeur instanceof Integer){
					valeursModifiees.add(valeur.toString());
				} else {
					valeursModifiees.add(valeur);
				}
			}
			StringBuilder sb = new StringBuilder();
			if(hasOptionsDetails(descriptionTable) && (tablesEnModification.contains(descriptionTable.getTableName()) || tablesEnSuppression.contains(descriptionTable.getTableName()))){
				sb.append("<a class=\"dropdown-toggle config\" data-toggle=\"dropdown\">Configure</a>");
				sb.append("<ul class=\"dropdown-menu\">");
				if(descriptionTable.getConfiguration().getEditRecordOp() && tablesEnModification.contains(descriptionTable.getTableName())){
					String urlEditer = "edittables/editerEnregistrement?provenance=detailsTable&tableName="+table+"&index="+compteur;
					String hdivUrlEditer = hdivWrapper.creerLienHDIV(urlEditer);
					roueCranteeUtil.ajouterBoutonEditer(hdivUrlEditer, sb);
				}
				if(descriptionTable.getConfiguration().getDeleteRecordOp() && tablesEnSuppression.contains(descriptionTable.getTableName())){
					String urlSupprimer = "edittables/supprimerEnregistrement?provenance=detailsTable&tableName="+table+"&index="+compteur;
					String hdivUrlSupprimer = hdivWrapper.creerLienHDIV(urlSupprimer);
					roueCranteeUtil.ajouterBoutonSupprimer(hdivUrlSupprimer,sb);
				}
			} else {
				sb.append("<span class='roue_absente'></span>");
			}
			valeursModifiees.add(sb.toString());

			listeSansClefs.add(valeursModifiees);
			compteur++;
		}

		datatablesOutputAjax.setEnregistrementsAlimentes(listeSansClefs);
		return datatablesOutputAjax;

	}


	private  final Map<String, Object> construireMapObjet(TableDescription table, Object objet) {
		Map<String, Object> donneesObjet = new HashMap<String, Object>();

		// Pour chaque colonne de la table, on invoque le getter sur
		// l'objet afin de recuperer la valeur de l'objet pour cette
		// colonne et on place ce couple dans la Map.
		for (ColumnDescription col : table.getColumnList()) {
			String propertyName = col.getPropertyName();
			Object value = null;
			try {
				Method getter = new PropertyDescriptor(propertyName, objet.getClass()).getReadMethod();
				value = getter.invoke(objet);
				if (col.isForeignKey() && value != null) {
					// En cas de foreingKey, on appelle la m�thode toString().
					Method objectToPK = value.getClass().getMethod("toString");
					value = objectToPK.invoke(value);
				}
			} catch (NoSuchMethodException e) {
				LOGGER.error(e);
				value = StringUtils.EMPTY;
			} catch (IntrospectionException e) {
				LOGGER.error(e);
				value = StringUtils.EMPTY;
			} catch (IllegalArgumentException e) {
				LOGGER.error(e);
				value = StringUtils.EMPTY;
			} catch (IllegalAccessException e) {
				LOGGER.error(e);
				value = StringUtils.EMPTY;
			} catch (InvocationTargetException e) {
				LOGGER.error(e);
				value = StringUtils.EMPTY;
			}

			donneesObjet.put(col.getColumnName(), value);
		}

		return donneesObjet;
	}

	private boolean hasOptionsDetails(TableDescription descriptionTable){
		return descriptionTable.getConfiguration().getEditRecordOp() || descriptionTable.getConfiguration().getDeleteRecordOp();
	}

	@Override
	@Transactional
	public Integer countDatatableFiltre(DatatablesInputAjax parametresStructures,TableDescription descriptionTable) throws BusinessServiceException{
		try {
			return this.referentielPS.countDatatableFiltre(Class.forName(descriptionTable.getEntityClassName()), parametresStructures, descriptionTable);
		} catch (ClassNotFoundException e) {
			throw new BusinessServiceException(e);
		}

	}

	@Transactional
	public byte[] exportExcel(String nomTable) throws BusinessServiceException{
		try {
		List<String> tablesOptimisees = new ArrayList<String>();
		tablesOptimisees.add("ta_code_postal");
		tablesOptimisees.add("ta_code_postal_historique");
		tablesOptimisees.add("ta_complement_structure_banq_lmtay890");
		tablesOptimisees.add("ta_referentiel_abe_lmtay967");

		if(tablesOptimisees.contains(nomTable)){
			
				List<TableDescription> tableList = this.getTableList();
				Class<?> classe = IntrospectionUtils.getEntite(nomTable, tableList);
				TableDescription tableDescription = IntrospectionUtils.getTableDescriptionFromTableName(tableList, nomTable);
				IntrospectionUtils.reorderColumns(tableDescription, this.getColumnsOrder(tableDescription));
				List<TaLibelleColonneTable> allLibelleColonneTable = this.getAllLibelleColonneTable();
				Map<String,String> enTetesCodeEtLibelle = exportBS.obtenirCorrespondanceCodeLibelle(allLibelleColonneTable, tableDescription);
				List<String> enTetesCode = new ArrayList<String>(enTetesCodeEtLibelle.keySet());
				List<String> listeFetch = IntrospectionUtils.getForeignKeysName(tableDescription);
				return this.referentielPS.getStreamingMYSQLResult(classe.getName(), enTetesCode, enTetesCodeEtLibelle,listeFetch);

		} else {
			List<TableDescription> tableList = this.getTableList();
			Class<?> classe = IntrospectionUtils.getEntite(nomTable, tableList);
			TableDescription tableDescription = IntrospectionUtils.getTableDescriptionFromTableName(tableList, nomTable);
			IntrospectionUtils.reorderColumns(tableDescription, this.getColumnsOrder(tableDescription));
			List<TaLibelleColonneTable> allLibelleColonneTable = this.getAllLibelleColonneTable();
			Map<String,String> enTetesCodeEtLibelle = exportBS.obtenirCorrespondanceCodeLibelle(allLibelleColonneTable, tableDescription);
			List<String> enTetesCode = new ArrayList<String>(enTetesCodeEtLibelle.keySet());
			List<Object> enregistrements = this.findAll(classe.getName());
			
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet;
			Cell cell;
			Row row;
			sheet = workbook.createSheet(nomTable);
			row = sheet.createRow(0);
			cell = row.createCell(0);
			int index = 0;
			for (String enTeteCode : enTetesCode) {
				cell = row.createCell(index);
				cell.setCellValue(enTeteCode);
				index++;
			}
		
			index = 0;
			row = sheet.createRow(1);
			for (String enTeteLibelle : enTetesCodeEtLibelle.values()) {
				cell = row.createCell(index);
				cell.setCellValue(enTeteLibelle);
				index++;
			}
		
			index = 0;
			int ligne = 2;

			for (Object enregistrement : enregistrements) {
				Class<?> classeIntrospection = enregistrement.getClass();
				index = 0;
				row = sheet.createRow(ligne);
				for (String code : enTetesCode) {
					cell = row.createCell(index);
					String valeurChamp ="";
					try {
						Field champ = classeIntrospection.getDeclaredField(code.toLowerCase());
						champ.setAccessible(true);
						if(champ.get(enregistrement)==null){
							valeurChamp = "";

						} else {
							valeurChamp = champ.get(enregistrement).toString();

						}
					} catch(NoSuchFieldException exception){
						//Si pas de champ c'est peut être disponible uniquement via un getter
						 Method methode = classeIntrospection.getDeclaredMethod("get"+code.charAt(0)+code.substring(1).toLowerCase());
						 valeurChamp = methode.invoke(enregistrement).toString();
					}
					cell.setCellValue(valeurChamp);
					index++;
				}
				ligne++;
				
			}
			
			ByteArrayOutputStream outBytesStream = new ByteArrayOutputStream();
			workbook.write(outBytesStream);
			byte[] byteArray = outBytesStream.toByteArray();
			return byteArray;

		}
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchMethodException | SecurityException | InvocationTargetException | IOException e) {
			throw new BusinessServiceException(e);
		}
	}

	@Override
	public int countActif(String className) throws BusinessServiceException {
		try {
			Class<?> clazz = Class.forName(className);
			return referentielPS.countActif(clazz);
		} catch (ClassNotFoundException cnfe) {
			throw new BusinessServiceException(cnfe);
		} catch (Exception e) {
			throw new BusinessServiceException(	"ReferentielBusinessServiceImpl", "count", e);
		}
	}

	@Override
	public int countClos(String className) throws BusinessServiceException {
		try {
			Class<?> clazz = Class.forName(className);
			return referentielPS.countClos(clazz);
		} catch (ClassNotFoundException cnfe) {
			throw new BusinessServiceException(cnfe);
		} catch (Exception e) {
			throw new BusinessServiceException("ReferentielBusinessServiceImpl", "count", e);
		}
	}

}

