package fr.icdc.dei.lm4.paraneo.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import fr.icdc.dei.lm4.paraneo.dao.SecuriteDAO;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaSecurite;

@Repository("securiteDAO")
public class SecuriteDAOImpl extends AbstractDAOBase<TaSecurite, String> implements SecuriteDAO {

	@SuppressWarnings("unchecked")
	private List<String> obtenirTables(List<String> groupes, String mode){
		Criteria critere = this.getSessionFactory().getCurrentSession().createCriteria(TaSecurite.class);
		critere.add(Restrictions.in("habilitation", groupes));
		critere.add(Restrictions.eq(mode,true));
		critere.setProjection(Projections.property("table"));
		List<String> resultat = critere.list();
		return resultat;
	}

	@Override
	public List<String> obtenirTablesAutoriseesEnConsultation(List<String> groupes) {
		return obtenirTables(groupes, "consultation");
	}

	@Override
	public List<String> obtenirTablesAutoriseesEnModification(List<String> groupes) {
		return obtenirTables(groupes, "modification");
	}

	@Override
	public List<String> obtenirTablesAutoriseesEnCreation(List<String> groupes) {
		return obtenirTables(groupes, "creation");
	}

	@Override
	public List<String> obtenirTablesAutoriseesEnSuppression(List<String> groupes) {
		return obtenirTables(groupes, "suppression");
	}

	@Override
	public List<String> obtenirTablesAutoriseesEnNotification(List<String> groupes) {
		return obtenirTables(groupes, "notification");
	}


}
