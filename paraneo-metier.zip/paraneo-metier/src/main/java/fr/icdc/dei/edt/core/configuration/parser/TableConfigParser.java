package fr.icdc.dei.edt.core.configuration.parser;

import java.util.Map;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;

public interface TableConfigParser {

	/**
	 * Retourne la liste des objets TableConfiguration..
	 */
	Map<String, TableConfigImpl> getTableConfigurations();

}