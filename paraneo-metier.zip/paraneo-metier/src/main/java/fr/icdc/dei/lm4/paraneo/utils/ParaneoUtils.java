package fr.icdc.dei.lm4.paraneo.utils;

import java.util.Calendar;
import java.util.Date;

import fr.icdc.dei.lm4.paraneo.entite.transverse.ParaneoConstantes;

public class ParaneoUtils {
	
	/**
	 * <p>Retourne la data maximum dans Paraneo (01/01/2076)<p>
	 * <p>Cela peut etre utilise pour:
	 * <ul>
	 * <li>date de fin d'effet</li>
	 * <li>date de fermeture</li>
	 * <li>date de cloture</li>
	 * </ul>
	 * </p>
	 * @return date maximum dans Paraneo
	 */
	public static Date obtenirDateMaximum(){
		Calendar calendrier = Calendar.getInstance();
		calendrier.set(Calendar.YEAR, ParaneoConstantes.ANNEE_MAXIMUM);
		calendrier.set(Calendar.MONTH, Calendar.JANUARY);
		calendrier.set(Calendar.DAY_OF_MONTH,01);
		return calendrier.getTime();
	}

}
