package fr.icdc.dei.lm4.paraneo.entite.transverse;

public class ParaneoConstantes {
	// Menu parent (non affiché à l'utilisateur
	final public static String CODE_MENU_SERVICES = "SERVICES";

	// Menu Accueil
	final public static String CODE_MENU_ACCUEIL = "ACCUEIL";

	// Menu EditTable
	final public static String CODE_MENU_EDITTABLES = "EDITTABLES";

	// Menu Hexaposte
	final public static String CODE_MENU_HEXAPOSTE = "HEXAPOSTE";
	
	public static final int ANNEE_MAXIMUM = 2076;
	
	public static final String FORMAT_PARAMETRES = "yyyy-MM-dd";
	
	/**
	 * Tables pouvant etre notifiees par l'application
	 */
	@SuppressWarnings("rawtypes")
	public static final Class[] TABLES_NOTIFIEES = {TaProfilTitulaireLmtay400.class,
		 TaTypeFiliereLmtay401.class,
		 TaListeOpcvmLmtay402.class,
		 TaCodeEditiqueLmtay403.class,
		 TaFormeJuridiqueDgiLmtay518.class,
		 TaCategSicovamDeClientLmtay524.class,
		 TaCategorieDeDeposantLmtay525.class,
		 TaLienCategClientSicovamLmtay533.class,
		 TaApparentementCdcLmtay538.class,
		 TaLienCategClientDeposantLmtay560.class,
		 TaClassificationBale2Lmtay717.class,
		 TaClassificationMifLmtay718.class,
		 TaFamilleCommercialeLmtay738.class,
		 TaNomenclatureDeClienteleLmtay774.class,
		 TaEtatPersonneMoraleLmtay786.class,
		 TaRegimeMatrimonialLmtay788.class,
		 TaTypeAdresseElectroniqueLmtay789.class,
		 TaTypeDeTiersLmtay791.class,
		 TaTypeSituationMatrimonialesLmtay792.class,
		 TaTypeDeGestionLmtay793.class,
		 TaTypeDeRestrictionSicovamLmtay794.class,
		 TaTypeCodificationDesTiersLmtay796.class,
		 TaTypeDeLienEntreTiersLmtay797.class,
		 TaCategorieContrepartieFmLmtay799.class,
		 TaModeDeGestionClientsLmtay831.class,
		 TaQualiteNormalQualitePolitesLmtay527.class,
		 TaQualiteNormaliseeLmtay520.class,
		 TaQualitePolitesseLmtay526.class,
		 TaCategorieDeClientLmtay523.class,
		 TaTypeUtilisationAdresseLmtay790.class,
		 TaTypeAdresseLmtay540.class,
		 TaResidenceFiscaleFicobaLmtay511.class,
		 TaTierCorrespInseeNomfaLmtay999.class,
		 TaRoleDeTiersLmtay778.class,
		 TaMetierOperationnelTiersLmtay787.class,
		 TaCorrespondanceMetierRoleLmtay719.class,
		 TaJourFerieTargetLmtay739.class,
		 TaConventionFiscaleFranceLmtay716.class,
		 TaDeviseLmtay502.class,
		 TaJourFerieBoursePlaceLmtay755.class,
		 TaJourFerieCambistePaysLmtay741.class,
		 TaJourFerieCdcLmtay591.class,
		 TaJourFerieCeLmtay596.class,
		 TaJourFerieLegalParPaysLmtay602.class,
		 TaJourFerieOcBdfLmtay603.class,
		 TaJourFeriePosteLmtay509.class,
		 TaJourFerieSitPepsLmtay984.class,
		 TaJourFerieTresorLmtay593.class,
		 TaPaysLmtay501.class,
		 TaTypeQualificationFiscaleCliLmtay983.class,
		 TaTypeQualificationFiscaleIntLmtay982.class,
		 TaCategorieEconomiqueLmtay930.class,
		 TaCodificationReglementaireLmtay997.class,
		 TaCategorieDeContrepartieBicLmtay830.class,
		 TaFamilleFiscaleLmtay934.class,
		 TaEtatDuClientLmtay532.class,
		 TaNatureJuridiqueFicobaLmtay504.class,
		 TaNomenclatInseeActivEconomLmtay677.class,
		 TaComplementStructureBanqLmtay890.class,
		 TaLieuDeCompensationLmtay891.class,
		 TaRegion2016.class,
		 TaCodePostal.class,
		 TaCommuneInsee.class,
		 TaDepartement.class,
		 TaRegionAdministrativeLmtay547.class,
		 TaCodeComptableElementaireGmtamo06.class,
		 TaUniteDeConfidentialiteFbLmtay894.class,
		 TaG3pPrestation.class,
		 TaG3pGrillePrixPrestation.class,
		 TaG3pFicheG3p.class
		 };

}
