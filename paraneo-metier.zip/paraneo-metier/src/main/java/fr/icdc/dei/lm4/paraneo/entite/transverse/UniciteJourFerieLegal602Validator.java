package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que la date du jour ferie YDJFER saisie dans la table ta_jour_ferie legal_par_pays_lmtay602 n'existe pas deja en base
* @author porsini
*
*/
public class UniciteJourFerieLegal602Validator extends DatabaseAccess implements ConstraintValidator<UniciteJourFerieLegal602, Date> {
	@Autowired
	private ReferentielBusinessService referentielService;

	private String nomTableTestee;

	@Override
    public void initialize(UniciteJourFerieLegal602 constraintAnnotation) {
		this.nomTableTestee = constraintAnnotation.nomTableTestee();
    }

    @Override
    public boolean isValid(Date value, ConstraintValidatorContext context) {
    	return this.referentielService.verifUniciteJourFerieLegal602(nomTableTestee, value);
    }
}
