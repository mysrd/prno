package fr.icdc.dei.lm4.paraneo.entite.transverse;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
* Verifie que l'entier (décimal sans fraction dans la BDD) est composé uniquement des caractères autorisés quelle que soit la zone de saisie
* @author porsini
*
*/
public class CaracAutorisesDecimalSansFractionValidator implements ConstraintValidator<CaracAutorisesDecimalSansFraction, Integer> {

	private int nbCarac;

	@Override
    public void initialize(CaracAutorisesDecimalSansFraction constraintAnnotation) {
 	   this.nbCarac = constraintAnnotation.nbCarac();
    }

    @Override
    public boolean isValid(Integer value, ConstraintValidatorContext context) {
    	String monIntEnString = String.valueOf(value);
//    	String monIntEnString = Integer.toString(value);
    	if (monIntEnString != null) {
    		monIntEnString = monIntEnString.trim();
    		   if (monIntEnString.length() > 0) {
    			   if (monIntEnString.length() > nbCarac) {
    				   return false;
    			   }
    			   for (int i = 0; i < monIntEnString.length(); i++) {
	                    if(!Character.isDigit(monIntEnString.charAt(i)) && monIntEnString.charAt(i)!=' '){
	                           return false;
	                    }
    			   }
    			   return true;
    		   }
    		   else{
    			   return true;
    		   }
    	   }
    	   else{
    		   return true;
    	   }
    }
}
