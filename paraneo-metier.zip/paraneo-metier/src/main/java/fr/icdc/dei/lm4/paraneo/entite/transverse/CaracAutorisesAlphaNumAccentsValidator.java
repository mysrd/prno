package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CaracAutorisesAlphaNumAccentsValidator implements ConstraintValidator<CaracAutorisesAlphaNumAccents, String> {

	@Override
	public void initialize(CaracAutorisesAlphaNumAccents constraintAnnotation) { }

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		for (int i = 0; i < value.length(); i++) {
			if (!Character.isLetterOrDigit(value.charAt(i))) {
				return false;
			}
		}
		return true;
	}

}
