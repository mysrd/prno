package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.lm4.paraneo.dao.SecuriteDAO;
import fr.icdc.dei.lm4.paraneo.metier.service.SecuriteBusinessService;
@Service("securiteService")
public class SecuriteBusinessServiceImpl implements SecuriteBusinessService {

	@Resource(name = "securiteDAO")
	private SecuriteDAO securiteDAO;

	private List<String> obtenirListeGroupes() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		List<String> listeGroupes = new ArrayList<String>();
		for (GrantedAuthority authority : auth.getAuthorities()) {
			listeGroupes.add(authority.getAuthority());
		}
		return listeGroupes;
	}

	@Override
	@Transactional
	public List<String> verifierAccesConsultation() {
		return securiteDAO.obtenirTablesAutoriseesEnConsultation(obtenirListeGroupes());
	}

	@Override
	@Transactional
	public List<String> verifierAccesModification() {
		return securiteDAO.obtenirTablesAutoriseesEnModification(obtenirListeGroupes());
	}

	@Override
	@Transactional
	public List<String> verifierAccesCreation() {
		return securiteDAO.obtenirTablesAutoriseesEnCreation(obtenirListeGroupes());
	}

	@Override
	@Transactional
	public List<String> verifierAccessSuppression() {
		return securiteDAO.obtenirTablesAutoriseesEnSuppression(obtenirListeGroupes());
	}

	@Override
	@Transactional
	public List<String> verifierAccessNotification() {
		return securiteDAO.obtenirTablesAutoriseesEnNotification(obtenirListeGroupes());
	}


}
