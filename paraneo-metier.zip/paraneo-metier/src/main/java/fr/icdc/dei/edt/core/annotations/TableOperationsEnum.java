package fr.icdc.dei.edt.core.annotations;

/**
 * Enumeration des operations disponnibles sur une table
 *  
 * @author ffernandez-e
 *
 */
public enum TableOperationsEnum {
	
	AddNewRecord(), EditRecord(), DeleteRecord(), ViewRecord();
	
	
	private TableOperationsEnum(){
		
	}
}
