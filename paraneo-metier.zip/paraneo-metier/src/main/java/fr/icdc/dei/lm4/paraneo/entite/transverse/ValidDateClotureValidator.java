package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDateClotureValidator implements ConstraintValidator<ValidDateCloture, Object> {

	@Override
	public void initialize(ValidDateCloture constraintAnnotation) { }

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if (value instanceof Horodatage) {
			Horodatage h = (Horodatage) value;
			Date dateCreation = h.getYdc000();
			Date dateCloture = h.getYdclot();
			if (dateCreation.after(dateCloture)) {
				return false;
			}
			else {
				return true;
			}
		}
		else if (value instanceof HorodatageG3p) {
			HorodatageG3p h = (HorodatageG3p) value;
			Date dateCreation = h.getYdc000();
			Date dateCloture = h.getYdclot();
			if (dateCreation.after(dateCloture)) {
				return false;
			}
			else {
				return true;
			}
		}
		return false;
	}

}
