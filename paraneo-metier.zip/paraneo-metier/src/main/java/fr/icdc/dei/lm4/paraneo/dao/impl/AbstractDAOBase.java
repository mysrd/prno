package fr.icdc.dei.lm4.paraneo.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;

import fr.icdc.dei.lm4.paraneo.dao.AbstractDAO;
import fr.icdc.dei.lm4.paraneo.utils.Alias;


@SuppressWarnings({"unchecked", "rawtypes"})
public abstract class AbstractDAOBase<T, ID extends Serializable> implements AbstractDAO<T, ID> {

	@Resource(name = "sessionFactory")
	private SessionFactory sessionFactory;

	private Class<T> persistentClass;

	public AbstractDAOBase() {
		this.persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
	}

	/**
	 * Retourne toutes les entités
	 *
	 * @return Entités
	 */
	public List<T> findAll() {
		return this.findByCriteria();
	}

	/**
	 * Retourne l'entité dont l'id est passé en param�tre
	 *
	 * @return Entité
	 */

	public T findById(ID id) {
		return (T) this.sessionFactory.getCurrentSession().get(getPersistentClass(), id);
	}

	public void saveOrUpdate(T entity) {
		this.sessionFactory.getCurrentSession().saveOrUpdate(entity);
	}


	/**
	 * Marque l'entité passée en paramétre comme étant en attente de
	 * persistance. Lors du prochain flush, l'entité sera enregistrée en base En
	 * cas de clear, l'ajout est abandonné.
	 *
	 * @param Entité à sauver
	 */
	public void insert(T entity) {
		this.sessionFactory.getCurrentSession().save(entity);
	}

	/**
	 * Marque l'entité passée en paramêtre commme étant en attente de mise à
	 * jour. Lors du prochain flush, l'entité sera enregistrée en base. En cas
	 * de clear, les modifications sont abandonnées.
	 *
	 * @param entity
	 */
	public void update(T entity) {
		this.sessionFactory.getCurrentSession().update(entity);
	}

	/**
	 * Marque l'entité passée en paramêtre comme étant en attente de
	 * suppression. Lors du prochain flush, l'entité sera supprimée en base. En
	 * cas de clear, la suppression est abondonnée.
	 *
	 * @param entity
	 */
	public void delete(T entity) {
		this.sessionFactory.getCurrentSession().delete(entity);
	}

	/**
	 * Méthode permettant la récupération des entités par criteria
	 *
	 * @param criteres
	 * @return
	 */
	public List<T> findByCriteria(Criterion... criteres) {
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass());

		for (Criterion c : criteres) {
			crit.add(c);
		}

		return crit.list();
	}

	public List<T> findByCriteria(int maxResults, Criterion... criteres) {
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass());

		for (Criterion c : criteres) {
			crit.add(c);
		}
		crit.setMaxResults(maxResults);
		return crit.list();
	}

	public List<T> findByCriteria(List<Alias> alias, String entityName, Criterion... criteres){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass(), entityName);

		this.createAlias(alias, crit);

		return this.restriction(crit, criteres);
	}

	public List<T> findByCriteria(List<Alias> alias, String entityName, Order ordre, Criterion... criteres){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass(), entityName);
		crit.addOrder(ordre);
		this.createAlias(alias, crit);

		return this.restriction(crit, criteres);
	}

	public List<T> findByCriteria(List<Alias> alias, String entityName, Order ordre, int maxResults, Criterion... criteres){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass(), entityName);
		crit.addOrder(ordre);
		crit.setMaxResults(maxResults);
		this.createAlias(alias, crit);

		return this.restriction(crit, criteres);
	}

	public List<T> findByCriteria(Order ordre, Criterion... criteres){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass());
		crit.addOrder(ordre);
		return this.restriction(crit, criteres);
	}

	/**
	 * Méthode permettant la récupération de données composites du ResultSet
	 *
	 * @param projection
	 * @param criteres
	 * @return
	 */
	public List findByProjection(Projection projections, Criterion... criteres) {
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass());
		return this.projectionAndRestriction(crit, projections, criteres);
	}

	/**
	 * Projection sur des attributs d'assocations (jointures)
	 * @param alias
	 * @param entityName
	 * @param projections
	 * @param criteres
	 * @return
	 */
	public List findByProjection(List<Alias> alias, String entityName, Projection projections, Criterion... criteres) {
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(getPersistentClass(), entityName);

		this.createAlias(alias, crit);

		return this.projectionAndRestriction(crit, projections, criteres);
	}


	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * getPersistentClass
	 *
	 * @return
	 */
	protected Class<T> getPersistentClass() {
		return this.persistentClass;
	}

	private List<T> restriction(Criteria crit, Criterion... criteres){

		for (Criterion c : criteres) {
			crit.add(c);
		}

		return crit.list();
	}

	private List projectionAndRestriction(Criteria crit, Projection projections, Criterion... criteres){
		crit.setProjection(projections);

		return this.restriction(crit, criteres);

	}

	private void createAlias(List<Alias> alias, Criteria crit){

		for(Alias al : alias){
			if (al.getJoinType() != null) {
				crit.createAlias(al.getAssociationPath(), al.getAlias(), al.getJoinType());
			} else {
				crit.createAlias(al.getAssociationPath(), al.getAlias());
			}
		}
	}
}
