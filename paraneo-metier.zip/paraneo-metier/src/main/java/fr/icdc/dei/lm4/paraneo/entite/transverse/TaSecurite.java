package fr.icdc.dei.lm4.paraneo.entite.transverse;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ta_securite")
public class TaSecurite implements Serializable {

	@Id
	@Column(name = "habilitation", nullable = false)
	private String habilitation;

	@Id
	@Column(name = "table", nullable = false)
	private String table;

	@Column(name = "consultation", nullable = false)
	private boolean consultation;

	@Column(name = "creation", nullable = false)
	private boolean creation;

	@Column(name = "modification", nullable = false)
	private boolean modification;

	@Column(name = "suppression", nullable = false)
	private boolean suppression;

	@Column(name = "notification", nullable = false)
	private boolean notification;

}
