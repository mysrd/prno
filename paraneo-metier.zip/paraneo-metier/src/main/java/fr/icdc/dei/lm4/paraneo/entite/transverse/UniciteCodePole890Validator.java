package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que le code pole saisi n'existe pas deja dans la table
* @author porsini
*
*/
public class UniciteCodePole890Validator extends DatabaseAccess implements ConstraintValidator<UniciteCodePole890, TaComplementStructureBanqLmtay890> {
	@Autowired
	private ReferentielBusinessService referentielService;

	@Override
    public void initialize(UniciteCodePole890 constraintAnnotation) {
    }

    @Override
    public boolean isValid(TaComplementStructureBanqLmtay890 classeValidee, ConstraintValidatorContext context) {

    	String cpole = null;
   		cpole = classeValidee.getCpole();
   		if (StringUtils.isBlank(cpole)){		// Le champ CPOLE peut être à blanc. Dans ce cas, on ne le teste pas.
   			return true;
   		}

    	return this.referentielService.verifUniciteCodePole(classeValidee.getCung(), cpole);
    }
}
