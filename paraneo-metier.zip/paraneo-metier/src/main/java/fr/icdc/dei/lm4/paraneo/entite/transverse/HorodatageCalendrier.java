package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Doit être hérité par les classes gérant les calendriers
 * @author porsini
 *
 */
@XmlAccessorType(XmlAccessType.NONE)
public abstract class HorodatageCalendrier {


	public abstract Date getYdjfer();

	public abstract void setYdjfer(Date ydjfer);

	public abstract Date getYdc000();

	public abstract void setYdc000(Date ydc000);

	public abstract String getCuser();

	public abstract void setCuser(String cuser);

	/**
	 * Initialise la date de du jour férié à aujourd'hui
	 */
	public void initialiserJourFerie(){
		this.setYdjfer(Calendar.getInstance().getTime());
	}

	/**
	 * Initialise la date de création à aujourd'hui
	 */
	public void initialiserDateCreation(){
		setYdc000(Calendar.getInstance().getTime());
	}

	public void definirUtilisateur(String utilisateur){
		this.setCuser(utilisateur);
	}

	@XmlElement(name="ydc000")
	public String getDateCreationWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdc000());
	}

	@XmlElement(name="ydjfer")
	public String getDateJourFerieWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdjfer());

	}



}
