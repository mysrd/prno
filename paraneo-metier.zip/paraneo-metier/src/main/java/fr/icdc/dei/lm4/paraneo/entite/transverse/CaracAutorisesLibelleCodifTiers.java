package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;


//Propriétés de l'annotation (meta-annotations)
@Retention(RetentionPolicy.RUNTIME)	// Cette nouvelle annotation est vue par la JVM
@Target(ElementType.FIELD)			// Elle ne s'applique que sur un champ
@Constraint(validatedBy=CaracAutorisesLibelleCodifTiersValidator.class)			// Nom de la classe où sera effectué la vérification
public @interface CaracAutorisesLibelleCodifTiers {
	String message() default "{paraneo.contrainte.caracteres.autorises.chaine}";
    Class<?>[] groups() default { };
    Class<? extends Payload>[] payload() default {};
}
