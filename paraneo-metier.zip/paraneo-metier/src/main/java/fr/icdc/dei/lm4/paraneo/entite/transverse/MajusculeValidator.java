package fr.icdc.dei.lm4.paraneo.entite.transverse;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Verifie que le string est compose uniquement de majuscules (hors espaces)
 * @author porsini
 *
 */
public class MajusculeValidator implements ConstraintValidator<Majuscule, String> {

	@Override
	public void initialize(Majuscule constraintAnnotation) {
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		for (int i = 0; i < value.length(); i++) {
			if(value.charAt(i)!=' ' && !Character.isUpperCase(value.charAt(i))){
				return false;
			}
		}
		return true;
	}

}
