package fr.icdc.dei.edt.core.configuration;

import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;

import fr.icdc.dei.edt.core.configuration.parser.converter.BasicConverterParser;
import fr.icdc.dei.edt.core.configuration.parser.converter.ConvertDateTimeParser;
import fr.icdc.dei.edt.core.configuration.parser.converter.ConvertNumberParser;
import fr.icdc.dei.edt.core.configuration.parser.converter.ConverterParser;
import fr.icdc.dei.edt.core.converter.BigDecimalConverter;
import fr.icdc.dei.edt.core.converter.BooleanConverter;
import fr.icdc.dei.edt.core.converter.ByteConverter;
import fr.icdc.dei.edt.core.converter.CharacterConverter;
import fr.icdc.dei.edt.core.converter.Converter;
import fr.icdc.dei.edt.core.converter.DateTimeConverter;
import fr.icdc.dei.edt.core.converter.DoubleConverter;
import fr.icdc.dei.edt.core.converter.FloatConverter;
import fr.icdc.dei.edt.core.converter.IntegerConverter;
import fr.icdc.dei.edt.core.converter.LongConverter;
import fr.icdc.dei.edt.core.converter.NumberConverter;
import fr.icdc.dei.edt.core.converter.ShortConverter;
import fr.icdc.dei.edt.core.util.LocaleUtils;

public class ConverterFactory {
	
	/*
	 * Les types de converters
	 * 
	 * Remarque : La DTD ou le schema XML n'autorisera que l'un de ces
	 * éléments, on suppose donc qu'il n'y a qu'un des éléments suivants :
	 * 
	 * <converter id="javax.faces.Short"/> 
	 * <converter className="javax.faces.Short"/> 
	 * <convertDateTime pattern="MM/yyyy"/>
	 * <convertNumber maxFractionDigits="2" groupingUsed="true" currencySymbol="$" maxIntegerDigits="7" type="currency"/>
	 */
	public Converter create(ConverterParser converterParser, String columnLabel){
		
		Converter converter = null;
		
		if (converterParser instanceof ConvertDateTimeParser){
			
			ConvertDateTimeParser convertDateTime = (ConvertDateTimeParser)converterParser;
			
			converter = createDateTimeConverter(convertDateTime, columnLabel);
		}
		

		else if (converterParser instanceof ConvertNumberParser){
			
			ConvertNumberParser convertNumberParser = (ConvertNumberParser)converterParser;
			
			converter = createNumberConverter(convertNumberParser, columnLabel);
		}
		
		else if  (converterParser instanceof BasicConverterParser){
			
			BasicConverterParser basicConverterParser = (BasicConverterParser)converterParser;
			
			converter = createBasicConverter(basicConverterParser, columnLabel);
			
		}
		
		return converter;
		
	}

	private Converter createBasicConverter(BasicConverterParser basicConverterParser, String columnLabel) {
		
		Converter converter = null;
		
		String value = basicConverterParser.getId();

		// cas 1 : <converter id="javax.faces.Short"/>
		if (value != null) {
			converter = createConverter(value, columnLabel);
		}

		else {
			// cas 2 : <converter className="fr.dei.MyConverter"/>
			
			value = basicConverterParser.getClassName();
			

			try {
				Class<?> converterClass = Class.forName(value);
				converter = (Converter) converterClass.newInstance();
				if (!(converter instanceof Converter)) {
					throw new ConfigurationException(
							"La classe : " + value + " n'étend pas l'interface 'fr.icdc.dei.edt.core.converter.Converter'");
				}
				converter.setLabel(columnLabel);
			} catch (ClassNotFoundException e) {
				throw new ConfigurationException(e);
			} catch (InstantiationException e) {
				throw new ConfigurationException(e);
			} catch (IllegalAccessException e) {
				throw new ConfigurationException(e);
			}

			if (value == null) {
				// Normalement le validateur XML n'autorisera pas
				// <converter> sans attribut
				// mais tant que la validateur n'est pas écrit on fait de
				// cette manière
				throw new ConfigurationException(
						"L'élément <converter> doit avoir soit l'attribut 'id' soit l'attribut 'className'");
			}
		}
	
		return converter;
	}

	private DateTimeConverter createDateTimeConverter(ConvertDateTimeParser converterParser, String columnLabel) {
		
		DateTimeConverter dateTimeConverter = new DateTimeConverter();
		
		dateTimeConverter.setLabel(columnLabel);

		
		String pattern = converterParser.getPattern();
		String dateStyle = converterParser.getDateStyle();
		String locale = converterParser.getLocale();
		String timeZone = converterParser.getTimeZone();
		String type = converterParser.getType();

		if (!StringUtils.isEmpty(pattern)) {
			dateTimeConverter.setPattern(pattern);
		}

		if (!StringUtils.isEmpty(dateStyle)) {
			dateTimeConverter.setDateStyle(dateStyle);
		}

		if (!StringUtils.isEmpty(locale)) {
			dateTimeConverter.setLocale(LocaleUtils.toLocale(locale));
		}

		if (!StringUtils.isEmpty(timeZone)) {
			dateTimeConverter.setTimeZone(TimeZone
					.getTimeZone(timeZone));
		}

		if (!StringUtils.isEmpty(type)) {
			dateTimeConverter.setType(type);
		}
		return dateTimeConverter;
	}
	
	private NumberConverter createNumberConverter(ConvertNumberParser convertNumberParser, String columnLabel){
		
		NumberConverter numberConverter = new NumberConverter();
		numberConverter.setLabel(columnLabel);
				
		String currencyCode = convertNumberParser.getCurrencyCode();
		String currencySymbol = convertNumberParser.getCurrencySymbol();
		String groupingUsed = convertNumberParser.getGroupingUsed();
		String integerOnly = convertNumberParser.getIntegerOnly();
		String locale = convertNumberParser.getLocale();
		String maxFractionDigits = convertNumberParser.getMaxFractionDigits();
		String maxIntegerDigits = convertNumberParser.getMaxIntegerDigits();
		String minFractionDigits = convertNumberParser.getMinFractionDigits();
		String minIntegerDigits = convertNumberParser.getMinIntegerDigits();
		String pattern = convertNumberParser.getPattern();
		String type = convertNumberParser.getType();

		
		if (!StringUtils.isEmpty(currencyCode)) {
			numberConverter.setCurrencyCode(currencyCode);
		}
		if (!StringUtils.isEmpty(currencySymbol)) {
			numberConverter.setCurrencySymbol(currencySymbol);
		}
		if (!StringUtils.isEmpty(groupingUsed)) {
			numberConverter.setGroupingUsed(Boolean.valueOf(groupingUsed).booleanValue());
		}
		if (!StringUtils.isEmpty(integerOnly)) {
			numberConverter.setIntegerOnly(Boolean.valueOf(integerOnly).booleanValue());
		}
		if (!StringUtils.isEmpty(locale)) {
			numberConverter.setLocale(LocaleUtils.toLocale(locale));
		}
		if (!StringUtils.isEmpty(maxFractionDigits)) {
			numberConverter.setMaxFractionDigits(Integer.parseInt(maxFractionDigits));
		}
		if (!StringUtils.isEmpty(maxIntegerDigits)) {
			numberConverter.setMaxIntegerDigits(Integer.parseInt(maxIntegerDigits));
		}
		if (!StringUtils.isEmpty(minFractionDigits)) {
			numberConverter.setMinFractionDigits(Integer.parseInt(minFractionDigits));
		}
		if (!StringUtils.isEmpty(minIntegerDigits)) {
			numberConverter.setMinIntegerDigits(Integer.parseInt(minIntegerDigits));
		}
		if (!StringUtils.isEmpty(pattern)) {
			numberConverter.setPattern(pattern);
		}
		if (!StringUtils.isEmpty(type)) {
			numberConverter.setType(type);
		}
		
		return numberConverter;
	}

	private static Converter createConverter(String converterId, String label) {
		Converter converter = null;

		if ("edittables.converter.Integer".equals(converterId)) {
			converter = new IntegerConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.BigDecimal".equals(converterId)) {
			converter = new BigDecimalConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Boolean".equals(converterId)) {
			converter = new BooleanConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Byte".equals(converterId)) {
			converter = new ByteConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Character".equals(converterId)) {
			converter = new CharacterConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Date".equals(converterId)) {
			converter = new DateTimeConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Double".equals(converterId)) {
			converter = new DoubleConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Float".equals(converterId)) {
			converter = new FloatConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Integer".equals(converterId)) {
			converter = new IntegerConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Long".equals(converterId)) {
			converter = new LongConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Number".equals(converterId)) {
			converter = new NumberConverter();
			converter.setLabel(label);
		}

		else if ("edittables.converter.Short".equals(converterId)) {
			converter = new ShortConverter();
			converter.setLabel(label);
		} else {
			throw new ConfigurationException("Type de converter inconnu : "	+ converterId);
		}
		return converter;
	}
}
