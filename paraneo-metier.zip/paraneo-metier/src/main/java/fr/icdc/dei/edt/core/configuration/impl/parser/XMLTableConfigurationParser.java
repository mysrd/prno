package fr.icdc.dei.edt.core.configuration.impl.parser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.dom4j.Document;
import org.dom4j.Node;

import fr.icdc.dei.edt.core.configuration.ConfigurationException;
import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;
import fr.icdc.dei.edt.core.configuration.parser.TableConfigParser;


public class XMLTableConfigurationParser implements TableConfigParser {

	private final Document editTablesConfDocument;

	public XMLTableConfigurationParser(Document editTablesConfDocument) {
		this.editTablesConfDocument = editTablesConfDocument;
	}


	@SuppressWarnings({ "unused", "rawtypes" })
	public Map<String, TableConfigImpl> getTableConfigurations() {

		// Récupération de la liste des nom de classes
		List<String> classNames = selectTableConfigurationPath();

		List<String> validationFiles;

		validationFiles = selectValidationFilesPath();

		Map<String, TableConfigImpl> tableConfigurationMap = new HashMap<String, TableConfigImpl>();

		Iterator<String> configFilesIter = classNames.iterator();

		// Pour toute les classes entités
		for (String className : classNames) {
			// On récupère la classe par reflexion
			Class clazz;
			try {
				clazz = Class.forName(className);
			} catch (ClassNotFoundException e) {
				throw new ConfigurationException("Impossible de trouver la classe '" + className + "'", e);
			}

			// On créer un parser
			AnnotationTableParser parser = new AnnotationTableParser(clazz);

			// On recupère les informations de la table
			TableConfigImpl tableConfig = parser.build();

			tableConfigurationMap.put(tableConfig.getName().toUpperCase(), tableConfig);
		}

		return tableConfigurationMap;
	}

	@SuppressWarnings("unused")
	private boolean populateTableOperation(boolean operation, final Document doc, final String xpathExpr, boolean defautOperation) {

		boolean returnedOperation = operation;

		boolean enabled = defautOperation;

		Node node = doc.selectSingleNode(xpathExpr);

		if (node != null) {
			// noeud trouv�, la pr�sence du noeud veut dire implicitement
			// on="true"
			enabled = true;
			String value = node.valueOf("@on");
			Boolean booleanValue = booleanValue(value);
			enabled = booleanValue != null ? booleanValue.booleanValue() : true;
			operation = enabled;

			returnedOperation = operation;

		}

		else {
			returnedOperation = defautOperation;
		}

		return returnedOperation;
	}

	/**
	 * R�cup�re la valeur de l'attribut "roles" de l'op�ration. Exemple : <add
	 * on="true" roles="Admin"/>
	 */
	@SuppressWarnings("unused")
	private List<String> selectTableOperationRoles(Node node1, String operationXpathExpr) {
		List<String> roles = new ArrayList<String>();
		Node node = node1.selectSingleNode(operationXpathExpr);
		if (node != null) {
			String value = node.valueOf("@roles");
			if (value != null)
				if (value.trim().length() != 0) {
					StringTokenizer st = new StringTokenizer(value, ",");
					while (st.hasMoreTokens()) {
						roles.add(st.nextToken().trim());
					}
				}
		}
		return roles;
	}

	/**
	 * Trouve les chemins des fichiers XML.
	 *
	 * Exemple :
	 *
	 * <pre>
	 * 	<tables defaultConfig="/fr/icdc/dei/sample/conf/settings/default-conf.xml">
	 * 	<table-config path="/fr/icdc/dei/sample/conf/settings/Client-conf.xml" />
	 *  	<table-config path="/fr/icdc/dei/sample/conf/settings/Categorie-conf.xml" />
	 * 	<table-config path="/fr/icdc/dei/sample/conf/settings/Commande-conf.xml" />
	 * 	<table-config path="/fr/icdc/dei/sample/conf/settings/Produit-conf.xml" />
	 * 	<table-config path="/fr/icdc/dei/sample/conf/settings/Utilisateur-conf.xml" />
	 * 		<table-config path="/fr/icdc/dei/sample/conf/settings/UserData-conf.xml" />
	 * </tables>
	 * </pre>
	 */
	@SuppressWarnings("unchecked")
	private List<String> selectTableConfigurationPath() {
		List<String> configFiles = new ArrayList<String>();
		List<Node> list = this.editTablesConfDocument.selectNodes("//table-config");
		Iterator<Node> listIter = list.iterator();
		while (listIter.hasNext()) {
			Node node = (Node) listIter.next();
			String configFilePath = node.valueOf("@path");
			configFiles.add(configFilePath);
		}
		return configFiles;
	}

	/**
	 * Trouve les chemins des fichiers de validation.
	 *
	 * Exemple :
	 *
	 * <pre>
	 * 	<validation>
	 *  <file path="/fr/icdc/dei/edit/technique/validation/validator-rules.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/my-validator-rules.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/Categorie-validation.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/Client-validation.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/Commande-validation.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/Produit-validation.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/UserData-validation.xml" />
	 *  <file path="/fr/icdc/dei/sample/conf/validation/Utilisateur-validation.xml" />
	 * </validation>
	 * </pre>
	 */
	@SuppressWarnings("unchecked")
	private List<String> selectValidationFilesPath() {
		List<String> configFiles = new ArrayList<String>();
		List<Node> list = this.editTablesConfDocument.selectNodes("//validation/file");
		Iterator<Node> listIter = list.iterator();
		while (listIter.hasNext()) {
			Node node = (Node) listIter.next();
			String configFilePath = node.valueOf("@path");
			configFiles.add(configFilePath);
		}
		return configFiles;
	}

	@SuppressWarnings("unused")
	private String selectTableName(Document document) {
		Node tableNode = document.selectSingleNode("/table");
		String tableName = tableNode.valueOf("@name");
		return tableName;
	}

	@SuppressWarnings("unused")
	private String selectTableLabel(Document document) {
		Node tableNode = document.selectSingleNode("/table");
		String tableName = tableNode.valueOf("@label");
		return tableName;
	}

	@SuppressWarnings("unused")
	private String selectValidationFormName(Document document) {
		Node tableNode = document.selectSingleNode("/table");
		String tableName = tableNode.valueOf("@form-validation-name");
		return tableName;
	}

	// /**
	// * Trouve les chemins vers le fichier de configuration par d�faut.
	// */
	// private String selectDefaultTableConfigurationPath() {
	// Node node = this.editTablesConfDocument.selectSingleNode("//tables");
	// return node.valueOf("@defaultConfig");
	//
	// }
	//
	// private boolean selectTableOperation(Document doc, String
	// operationXpathExpr, boolean defautValue){
	// boolean operation = defautValue;
	// Node node = doc.selectSingleNode(operationXpathExpr);
	// if (node != null){
	// // noeud trouv�, la pr�sence du noeud veut dire implicitement on="true"
	// operation = true;
	// String value = node.valueOf("@on");
	// Boolean booleanValue = booleanValue(value);
	// operation = booleanValue !=null ? booleanValue.booleanValue() : true;
	// }
	// return operation;
	// }

	/**
	 * Retourne true si la chaine en entr�e est "true" Retourne false si la
	 * chaine en entr�e est "false" Retourne null si la chaine en entr�e est
	 * null Retourne null si la chaine en entr�e est vide
	 *
	 * @param value
	 *            La valeur text � traduire en boolean
	 * @return false si value est null.
	 */
	private Boolean booleanValue(String value) {

		Boolean booleanValue = null;

		if (value != null && !value.trim().equals("")) {
			if ("false".equals(value)) {
				booleanValue = Boolean.FALSE;
			} else if ("true".equals(value)) {
				booleanValue = Boolean.TRUE;
			} else {
				throw new ConfigurationException("valeur : '" + value + "' non support�e");
			}
		}
		return booleanValue;
	}

	@SuppressWarnings("unused")
	private int selectPagination(Document doc, int defautValue) {

		int rows = defautValue;

		Node node = doc.selectSingleNode("//pagination");

		if (node != null) {

			String value = node.valueOf("@rows");

			if (value == null) {
				throw new ConfigurationException("Dans l'�l�ment <pagination> l'attribut 'rows' est obligatoire");
			} else {
				try {
					rows = Integer.valueOf(value).intValue();
				} catch (NumberFormatException e) {
					throw new ConfigurationException(e);
				}
			}
		}

		return rows;
	}
}
