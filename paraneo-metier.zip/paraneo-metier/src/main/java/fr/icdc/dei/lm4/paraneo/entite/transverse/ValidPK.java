package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy=ValidPKValidator.class)
public @interface ValidPK {
	
	String startwith() default "alpha";
	int startsize() default -1;
	
	String endwith() default "digit";
	int endsize() default -1;

	String message() default "{paraneo.contrainte.validpk}";

	Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
