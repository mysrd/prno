package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

public abstract class HorodatageDebut extends Horodatage {

	public abstract Date getYdde();
	public abstract void setYdde(Date ydde);
	
	public abstract Date getYdfe();
	public abstract void setYdfe(Date ydfe);
}
