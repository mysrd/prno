package fr.icdc.dei.edt.core.description.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.mapping.Column;
import org.hibernate.mapping.Component;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.type.CollectionType;
import org.hibernate.type.Type;

import fr.icdc.dei.edt.core.configuration.impl.TableConfigImpl;
import fr.icdc.dei.edt.core.configuration.impl.parser.AnnotationTableParser;
import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.core.description.TableDescriptionBuilder;

public class HibernateTableDescriptionBuilder implements TableDescriptionBuilder {

	private String idClassName;
	private String idName;
	private PersistentClass persistentClass;
	private boolean isCompositeId;

	/**
	 * Les nom de colonne de la clé primaire.
	 */
	private List<String> idColumns = new ArrayList<String>();

	private List<ColumnDescription> columnList = new ArrayList<ColumnDescription>();

	private Map<String, ColumnDescription> className_columnDescriptionMap = new HashMap<String, ColumnDescription>();

	private Map<String, ColumnDescription> propertyName_columnDescriptionMap = new HashMap<String, ColumnDescription>();

	private TableDescription tableDescription;

	private TableConfigImpl configuration;

	private Set<String> classes;

	public HibernateTableDescriptionBuilder(PersistentClass persistentClass, Set<String> classes) {

		this.persistentClass = persistentClass;
		this.classes = classes;
	}

	public TableDescription build() throws SecurityException, NoSuchFieldException {
		String entityClassName = persistentClass.getClassName();
		String tableName = persistentClass.getTable().getName();

		// FIXME : Problème de design, rendre cette partie plus Orientée Objet
		AnnotationTableParser parser = new AnnotationTableParser(persistentClass.getMappedClass());
		TableConfigImpl conf = parser.build();
		setupId();
		setupColumnList();
		tableDescription = new TableDescription(conf, entityClassName, tableName, idName, idClassName, isCompositeId, columnList,
				className_columnDescriptionMap, propertyName_columnDescriptionMap);

		return tableDescription;
	}

	// FIXME : Présence de code redondant
	@SuppressWarnings("unchecked")
	private void setupId() {
		Property idProperty = persistentClass.getIdentifierProperty();

		if (idProperty != null) {
			idClassName = idProperty.getType().getReturnedClass().getName();
			idName = idProperty.getName();

			Iterator<Column> columnIterator = (Iterator<Column>) idProperty.getColumnIterator();
			while (columnIterator.hasNext()) {
				Column column = (Column) columnIterator.next();
				idColumns.add(column.getName());
			}
			HibernateColumnDescriptionBuilder columnBuilder = new HibernateColumnDescriptionBuilder(idProperty, true, isCompositeId, null, tableDescription,
					classes);

			ColumnDescription columnDescription = columnBuilder.build();
			columnList.add(columnDescription);
			className_columnDescriptionMap.put(columnDescription.getColumnName(), columnDescription);
			propertyName_columnDescriptionMap.put(columnDescription.getIdPropertyName(), columnDescription);

		} else {
			Component idComponent = persistentClass.getIdentifierMapper();
			isCompositeId = true;
			Iterator<Column> columnIterator = (Iterator<Column>) idComponent.getColumnIterator();
			while (columnIterator.hasNext()) {
				Column column = (Column) columnIterator.next();
				idColumns.add(column.getName());
			}
			Iterator<Property> propertyIterator = idComponent.getPropertyIterator();

			while (propertyIterator.hasNext()) {
				HibernateColumnDescriptionBuilder columnBuilder = new HibernateColumnDescriptionBuilder(propertyIterator.next(), true, isCompositeId, null,
						tableDescription, classes);

				ColumnDescription columnDescription = columnBuilder.build();
				columnList.add(columnDescription);
				className_columnDescriptionMap.put(columnDescription.getColumnName(), columnDescription);
				propertyName_columnDescriptionMap.put(columnDescription.getIdPropertyName(), columnDescription);
			}
		}
	}

	@SuppressWarnings("unchecked")
	private void setupColumnList() throws SecurityException, NoSuchFieldException {
		// Récupération d'un iterator sur les propriétés de la classe
		// persistante.
		//

		Iterator<Property> iterator = persistentClass.getPropertyIterator();

		while (iterator.hasNext()) {

			Property property = (Property) iterator.next();

			if (!isIdentifier(property)) {
				// Cas 3 : Colonne ordinaire
				HibernateColumnDescriptionBuilder columnBuilder = new HibernateColumnDescriptionBuilder(property, false, isCompositeId, null, tableDescription,
						classes);

				Type propertyType = property.getType();

				if (!(propertyType instanceof CollectionType)) {

					List<ColumnDescription> columnDescriptionList = columnBuilder.build2();

					for (ColumnDescription columnDescription : columnDescriptionList) {
						columnList.add(columnDescription);
						className_columnDescriptionMap.put(columnDescription.getColumnName(), columnDescription);
						propertyName_columnDescriptionMap.put(columnDescription.getPropertyName(), columnDescription);
					}

				}
			}
		}

		// Object[] test = metadata.getPropertyValues(entityClass);
		/*
		 * String[] iterator = metadata.getPropertyNames();
		 * 
		 * List<Field> champs = new ArrayList<Field>();
		 * 
		 * for (Field field : this.entityClass.getDeclaredFields()) {
		 * javax.persistence.Column annotation = (javax.persistence.Column)
		 * field.getAnnotation(javax.persistence.Column.class); if (annotation
		 * != null) { champs.add(field);
		 * 
		 * if (!isIdentifier(field)) { // Cas 3 : Colonne ordinaire
		 * 
		 * HibernateColumnDescriptionBuilder columnBuilder = new
		 * HibernateColumnDescriptionBuilder(null, false, false, null,
		 * tableDescription, columnConfigurationMap, defaultColumnConfiguration,
		 * classes);
		 * 
		 * Type propertyType = metadata.getPropertyType(field.getName());
		 * 
		 * if (!(propertyType instanceof CollectionType)) {
		 * 
		 * List<ColumnDescription> columnDescriptionList =
		 * columnBuilder.build2();
		 * 
		 * for (ColumnDescription columnDescription : columnDescriptionList) {
		 * columnList.add(columnDescription);
		 * className_columnDescriptionMap.put(columnDescription.getColumnName(),
		 * columnDescription);
		 * propertyName_columnDescriptionMap.put(columnDescription
		 * .getPropertyName(), columnDescription); }
		 * 
		 * } } } }
		 */

		/*
		 * for (String prop : iterator) {
		 * 
		 * //Property property = (Property) metadata.
		 * getPropertyValue(metadata.getMappedClass(), prop);
		 * 
		 * if (!isIdentifier(property)) { // Cas 3 : Colonne ordinaire
		 * HibernateColumnDescriptionBuilder columnBuilder = new
		 * HibernateColumnDescriptionBuilder(property, false, false, null,
		 * tableDescription, columnConfigurationMap, defaultColumnConfiguration,
		 * classes);
		 * 
		 * Type propertyType = property.getType();
		 * 
		 * if (!(propertyType instanceof CollectionType)) {
		 * 
		 * List<ColumnDescription> columnDescriptionList =
		 * columnBuilder.build2();
		 * 
		 * for (ColumnDescription columnDescription : columnDescriptionList) {
		 * columnList.add(columnDescription);
		 * className_columnDescriptionMap.put(columnDescription.getColumnName(),
		 * columnDescription);
		 * propertyName_columnDescriptionMap.put(columnDescription
		 * .getPropertyName(), columnDescription); }
		 * 
		 * } } }
		 */
	}

	@SuppressWarnings("unchecked")
	private boolean isIdentifier(Property property) {
		Iterator<Column> columnIterator = (Iterator<Column>) property.getColumnIterator();
		while (columnIterator.hasNext()) {
			Column column = (Column) columnIterator.next();

			if (idColumns.contains(column.getName())) {
				return true;
			}
		}
		return false;
	}

}
