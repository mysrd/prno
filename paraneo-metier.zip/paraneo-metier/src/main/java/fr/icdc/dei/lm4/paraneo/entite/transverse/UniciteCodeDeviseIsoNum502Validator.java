package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;

/**
* Verifie que le code devise ISO NUM saisi n'existe pas deja dans la table
* @author porsini
*
*/
public class UniciteCodeDeviseIsoNum502Validator extends DatabaseAccess implements ConstraintValidator<UniciteCodeDeviseIsoNum502, TaDeviseLmtay502> {
	@Autowired
	private ReferentielBusinessService referentielService;

	@Override
    public void initialize(UniciteCodeDeviseIsoNum502 constraintAnnotation) {
    }

    @Override
    public boolean isValid(TaDeviseLmtay502 classeValidee, ConstraintValidatorContext context) {

    	String valeurDuChamp = null;
   		valeurDuChamp = classeValidee.getCndeva();
   		if (StringUtils.isBlank(valeurDuChamp)){		// Le champ CNDEVA peut être à blanc. Dans ce cas, on ne le teste pas.
   			return true;
   		}

    	return this.referentielService.verifUniciteCodeDeviseIsoNum502(classeValidee.getCdev(),valeurDuChamp);
    }
}
