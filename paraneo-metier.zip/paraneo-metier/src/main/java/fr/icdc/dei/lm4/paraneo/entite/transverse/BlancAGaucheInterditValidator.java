package fr.icdc.dei.lm4.paraneo.entite.transverse;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Verifie que le string ne commence pas par " "
 *
 */
public class BlancAGaucheInterditValidator implements ConstraintValidator<BlancAGaucheInterdit, String> {

	@Override
	public void initialize(BlancAGaucheInterdit constraintAnnotation) {
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
            if(value.startsWith(" ")){
			return false;
		}
		return true;
	}

}
