package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.edt.persistance.service.GenericPersistenceService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.LigneCompteRenduHexaposte;
import fr.icdc.dei.lm4.paraneo.entite.transverse.LigneHexaposte;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaCodePostal;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaParametrage;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.HexaposteService;
import fr.icdc.dei.lm4.paraneo.metier.service.NotificationDidoBusinessService;
import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

@Service("hexaposteBusinessService")
public class HexaposteServiceImpl implements HexaposteService {

	@Autowired
	private GenericPersistenceService editTablesPersistanceService;

	@Resource(name = "notificationDido")
	private NotificationDidoBusinessService notifDidoBS;

	private static final Logger LOGGER = Logger.getLogger(HexaposteServiceImpl.class);

	private List<LigneCompteRenduHexaposte> lignesCreation;
	private List<LigneCompteRenduHexaposte> lignesMAJ;
	private List<LigneCompteRenduHexaposte> lignesCloturees;

	// Ce caractere est le caractere "SUB". Il est present dans la derniere ligne du fichier et il faut l'ignorer
	// Voir : https://en.wikipedia.org/wiki/Substitute_character
	private final String caractereFinDeFichier = "\u001a";

	@Override
	@Transactional(rollbackFor=BusinessServiceException.class)
	public byte[] lancerTraitementHexaposte(InputStream fichierHexaposte, String nomUtilisateur) throws BusinessServiceException {
		LOGGER.debug("Lancement du traitement Hexaposte");

		lignesCreation = new ArrayList<LigneCompteRenduHexaposte>();
		lignesMAJ = new ArrayList<LigneCompteRenduHexaposte>();
		lignesCloturees = new ArrayList<LigneCompteRenduHexaposte>();

		// Ajout d'une ligne dans la table technique pour marquer le debut du traitement
		try {
			//Ouverture du fichier
			InputStreamReader inputStreamReader = new InputStreamReader(fichierHexaposte);
			BufferedReader fileInputStream = new BufferedReader(inputStreamReader);

			// On ne prend pas en compte la ligne d'en tete pour l'instant
			String ligne;
			int compteurLecture = 0;
			int compteurCreation = 0;
			int compteurMaj = 0;
			fileInputStream.readLine();
			Date dateTraitement = new Date();

			// Faut recuperer toutes les lignes de la table dans un tableau
			List<Object> enregistrements =  editTablesPersistanceService.findAll(TaCodePostal.class.getName());
			Map<String, TaCodePostal> mapEnregistrements = new HashMap<String, TaCodePostal>();

			for(Object enregistrement : enregistrements) {
				TaCodePostal enregistrementCaste = (TaCodePostal) enregistrement;
				mapEnregistrements.put(enregistrementCaste.getIdtl6(), enregistrementCaste);
			}


			while((ligne = fileInputStream.readLine())!=null){
				if(ligne.equals(caractereFinDeFichier)){
					break;
				}
				compteurLecture++;
				LigneHexaposte ligneHexaposte = decomposerLigneHexaposte(ligne);
				// Requete pour savoir si la ligne existe
				TaCodePostal enregistrement = mapEnregistrements.get(ligneHexaposte.getIdentifiant().trim());//(TaCodePostal) service.findById(TaCodePostal.class, ligneHexaposte.getIdentifiant());

				// On retire de la map l'enregistrement present dans le fichier qui a donne lieu a un traitement
				// On retire le lien entre la clef et la valeur
				mapEnregistrements.remove(ligneHexaposte.getIdentifiant());
				// On retire la valeur de la liste des valeurs de la map
				mapEnregistrements.values().remove(enregistrement);

				if(enregistrement==null){ // Si la ligne n'existe pas
					//on la cree
					LOGGER.debug("La ligne n'existe pas en base");
					TaCodePostal nouvelEnregistrement = new TaCodePostal();
					nouvelEnregistrement.setYddeff(dateTraitement);
					nouvelEnregistrement.setYdfeff(ParaneoUtils.obtenirDateMaximum());
					nouvelEnregistrement.setYdc000(dateTraitement);
					nouvelEnregistrement.setYddmaj(dateTraitement);
					nouvelEnregistrement.setYdclot(ParaneoUtils.obtenirDateMaximum());
					nouvelEnregistrement.setCuser(nomUtilisateur);

					nouvelEnregistrement = copierLigneFichierDansEnregistrementTablePourCreation(ligneHexaposte, nouvelEnregistrement);
					lignesCreation.add(new LigneCompteRenduHexaposte(ligneHexaposte));
					editTablesPersistanceService.create(nouvelEnregistrement);
					compteurCreation++;

				} else { // Si la ligne existe
					if(enregistrement.getYdfeff().after(dateTraitement)){
						if(!comparerLigneFichierEtEnregistrementTable(ligneHexaposte, enregistrement)){
							LOGGER.debug("La date de fin d'effet est posterieure a la date de traitement et l'enregistrement et la ligne sont differents");
							lignesMAJ.add(new LigneCompteRenduHexaposte(ligneHexaposte,enregistrement));
							copierLigneFichierDansEnregistrementTablePourModification(ligneHexaposte,enregistrement);
							enregistrement.setYddmaj(dateTraitement);
							enregistrement.setCuser(nomUtilisateur);
							editTablesPersistanceService.update(enregistrement);
							compteurMaj++;
						} else {
							LOGGER.debug("La date de fin d'effet est posterieure a la date de traitement et l'enregistrement et la ligne sont identiques");
						}
					} else {
						if(!comparerLigneFichierEtEnregistrementTable(ligneHexaposte, enregistrement)){
							LOGGER.debug("La date de fin d'effet est inferieure ou egale a la date de traitement et l'enregistrement et la ligne sont differents");
							copierLigneFichierDansEnregistrementTablePourModification(ligneHexaposte,enregistrement);
						} else {
							LOGGER.debug("La date de fin d'effet est inferieure ou egale a la date de traitement et l'enregistrement et la ligne sont identiques");
						}
						lignesMAJ.add(new LigneCompteRenduHexaposte(ligneHexaposte,enregistrement));
						enregistrement.setYddmaj(dateTraitement);
						enregistrement.setYddeff(dateTraitement);
						enregistrement.setYdfeff(ParaneoUtils.obtenirDateMaximum());
						enregistrement.setCuser(nomUtilisateur);

						editTablesPersistanceService.update(enregistrement);
						compteurMaj++;
					}

				}

				LOGGER.debug("Une ligne du fichier Hexaposte traitee");
			}

			// On s'occupe des lignes en base qui ne figurent pas dans le fichier
			for (TaCodePostal enregistrement : mapEnregistrements.values()) {
				if(enregistrement.getYdfeff().after(dateTraitement)){
					enregistrement.setYddmaj(dateTraitement);
					enregistrement.setYdfeff(dateTraitement);
					enregistrement.setCuser(nomUtilisateur);
					lignesCloturees.add(new LigneCompteRenduHexaposte(enregistrement));
					editTablesPersistanceService.update(enregistrement);
					compteurMaj++;
				}
			}

			LOGGER.debug("Nombre de lignes lues:"+compteurLecture);
			LOGGER.debug("Nombre de créations:"+compteurCreation);
			LOGGER.debug("Nombre de mises à jour:"+compteurMaj);
			LOGGER.debug("Fin du traitement Hexaposte");

			return genererRapportTraitement();
		} catch (IOException | IllegalArgumentException | SecurityException e) {
			LOGGER.debug("Erreur lors de la lecture du fichier Hexaposte",e);
			throw new BusinessServiceException(e);
		} finally {
			try {
				fichierHexaposte.close();
			} catch (IOException e) {
				LOGGER.debug("Erreur lors de la fermeture du fichier Hexaposte",e);
				throw new BusinessServiceException(e);
			}
		}


	}

	public void envoyerNotificationsDido() {			// [GZ - 11488] - Changement le nom de la table de tacodepostal à TACODEPOSTAL
		for (LigneCompteRenduHexaposte ligneCompteRenduHexaposte : lignesCreation) {
			notifDidoBS.envoyerNotificationCreationSimple(ligneCompteRenduHexaposte.getIdentifiant(), "TACODEPOSTAL");
		}

		for (LigneCompteRenduHexaposte ligneCompteRenduHexaposte : lignesMAJ) {
			notifDidoBS.envoyerNotificationModificationSimple(ligneCompteRenduHexaposte.getIdentifiant(), "TACODEPOSTAL");

		}

		for (LigneCompteRenduHexaposte ligneCompteRenduHexaposte : lignesCloturees) {
			notifDidoBS.envoyerNotificationModificationSimple(ligneCompteRenduHexaposte.getIdentifiant(), "TACODEPOSTAL");
		}

	}

	/**
	 * Decompose une ligne du fichier Hexaposte et retourne l'objet LigneHexaposte correspondant
	 * @param ligne
	 * @return
	 */
	public LigneHexaposte decomposerLigneHexaposte(String ligne){
		LigneHexaposte objetLigneHexaposte = new LigneHexaposte();

		//On decoupe la ligne
		objetLigneHexaposte.setIdentifiant(ligne.substring(0,6)); 						// Identifiant adresse
		objetLigneHexaposte.setCodeINSEE(ligne.substring(6,11));						// Code INSEE de la commune
		objetLigneHexaposte.setLibelle(ligne.substring(11,49)); 						// Libelle de la commune
		objetLigneHexaposte.setIndicateurDePluridistribution(ligne.substring(49,50)); 	// Indicateur de pluridistribution
		objetLigneHexaposte.setTypeCodePostal(ligne.substring(50,51)); 					// Type de code postal
		objetLigneHexaposte.setLibelleLigne5(ligne.substring(51,89)); 					// Libelle de la ligne 5
		objetLigneHexaposte.setCodePostal(ligne.substring(89,94));						// Code postal
		objetLigneHexaposte.setLibelleAcheminement(ligne.substring(94, 126)); 			// Libelle acheminement
		objetLigneHexaposte.setCodeINSEEAncienneCommune(ligne.substring(126, 131)); 	// Code INSEE ancienne commune
		objetLigneHexaposte.setCodeDeMiseAJour(ligne.substring(131, 132)); 				// Code de mise à jour
		objetLigneHexaposte.setCEA(ligne.substring(132,142)); 							// CEA

		return objetLigneHexaposte;
	}

	/**
	 * Retourne <b>true</b> si le fichier et l'enregistrement ont des donnees identiques<br/>
	 * Retourne <b>false</b> si leurs donnees sont differentes
	 * @param ligneFichier
	 * @param enregistrementTable
	 * @return
	 */
	public boolean comparerLigneFichierEtEnregistrementTable(LigneHexaposte ligneFichier, TaCodePostal enregistrementTable){
		if(!ligneFichier.getCodeINSEE().trim().equals(enregistrementTable.getCog5c().trim())){
			return false;
		}

		if(!ligneFichier.getLibelle().trim().equals(enregistrementTable.getLibcom().trim())){
			return false;
		}

		if(!ligneFichier.getIndicateurDePluridistribution().equals(enregistrementTable.getPludis())){
			return false;
		}

		if(!ligneFichier.getTypeCodePostal().equals(enregistrementTable.getTypecp())){
			return false;
		}

		if(!ligneFichier.getLibelleLigne5().trim().equals(enregistrementTable.getLibl5().trim())){
			return false;
		}

		if(!ligneFichier.getCodePostal().equals(enregistrementTable.getCodpos())){
			return false;
		}

		if(!ligneFichier.getLibelleAcheminement().trim().equals(enregistrementTable.getLibach().trim())){
			return false;
		}

		if(!ligneFichier.getCodeINSEEAncienneCommune().trim().equals(enregistrementTable.getAnccom().trim())){
			return false;
		}

		if(!ligneFichier.getCodeDeMiseAJour().trim().equals(enregistrementTable.getCodmaj().trim())){
			return false;
		}

		if(!ligneFichier.getCEA().trim().equals(enregistrementTable.getCea().trim())){
			return false;
		}

		return true;
	}


	public TaCodePostal copierLigneFichierDansEnregistrementTablePourCreation(LigneHexaposte ligneFichier, TaCodePostal enregistrement){
		enregistrement.setIdtl6(ligneFichier.getIdentifiant());
		enregistrement.setCog5c(ligneFichier.getCodeINSEE());
		enregistrement.setLibcom(ligneFichier.getLibelle());
		enregistrement.setPludis(ligneFichier.getIndicateurDePluridistribution());
		enregistrement.setTypecp(ligneFichier.getTypeCodePostal());
		enregistrement.setLibl5(ligneFichier.getLibelleLigne5());
		enregistrement.setCodpos(ligneFichier.getCodePostal());
		enregistrement.setLibach(ligneFichier.getLibelleAcheminement());
		enregistrement.setAnccom(ligneFichier.getCodeINSEEAncienneCommune());
		enregistrement.setCodmaj(ligneFichier.getCodeDeMiseAJour());
		enregistrement.setCea(ligneFichier.getCEA());

		return enregistrement;

	}

	public TaCodePostal copierLigneFichierDansEnregistrementTablePourModification(LigneHexaposte ligneFichier, TaCodePostal enregistrement){
		enregistrement.setCog5c(ligneFichier.getCodeINSEE());
		enregistrement.setLibcom(ligneFichier.getLibelle());
		enregistrement.setPludis(ligneFichier.getIndicateurDePluridistribution());
		enregistrement.setTypecp(ligneFichier.getTypeCodePostal());
		enregistrement.setLibl5(ligneFichier.getLibelleLigne5());
		enregistrement.setCodpos(ligneFichier.getCodePostal());
		enregistrement.setLibach(ligneFichier.getLibelleAcheminement());
		enregistrement.setAnccom(ligneFichier.getCodeINSEEAncienneCommune());
		enregistrement.setCodmaj(ligneFichier.getCodeDeMiseAJour());
		enregistrement.setCea(ligneFichier.getCEA());

		return enregistrement;

	}

	public byte[] genererRapportTraitement() throws BusinessServiceException{
		ByteArrayOutputStream fluxMemoire = new ByteArrayOutputStream();
		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet feuilleResume;
			Sheet sheet;
			Cell cell;
			Row row;

			Date dateDuJour = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("EE dd MMMM yyyy");

			feuilleResume = workbook.createSheet("Résumé");
			row = feuilleResume.createRow(0);

			cell = row.createCell(0);
			cell.setCellValue("Compte rendu Hexaposte du "+sdf.format(dateDuJour));

			row = feuilleResume.createRow(1);
			cell = row.createCell(0);
			cell.setCellValue("Nombre de créations:");
			cell = row.createCell(1);
			cell.setCellValue(this.lignesCreation.size());

			row = feuilleResume.createRow(2);
			cell = row.createCell(0);
			cell.setCellValue("Nombre de mises à jour:");
			cell = row.createCell(1);
			cell.setCellValue(this.lignesMAJ.size());

			row = feuilleResume.createRow(3);
			cell = row.createCell(0);
			cell.setCellValue("Nombre de clôtures:");
			cell = row.createCell(1);
			cell.setCellValue(this.lignesCloturees.size());

			sheet = workbook.createSheet("Détail");
			// Ecriture de la ligne d'entete
			row = sheet.createRow(0);
			cell = row.createCell(0);
			cell.setCellValue("Type d'opération");
			cell = row.createCell(1);
			cell.setCellValue("Identifiant Hexaposte");
			cell = row.createCell(2);
			cell.setCellValue("Code Postal avant");
			cell = row.createCell(3);
			cell.setCellValue("Code Postal après");
			cell = row.createCell(4);
			cell.setCellValue("Code Commune avant");
			cell = row.createCell(5);
			cell.setCellValue("Code Commune après");
			cell = row.createCell(6);
			cell.setCellValue("Libellé avant");
			cell = row.createCell(7);
			cell.setCellValue("Libellé après");
			cell = row.createCell(8);
			cell.setCellValue("Ligne 5 avant");
			cell = row.createCell(9);
			cell.setCellValue("Ligne 5 après");


			int compteurLigne = 1;
			// On trace les creations de codes postaux
			for ( LigneCompteRenduHexaposte ligne : lignesCreation) {
				row = sheet.createRow(compteurLigne);
				cell = row.createCell(0);
				cell.setCellValue("Creation");
				cell = row.createCell(1);
				cell.setCellValue(ligne.getIdentifiant());
				cell = row.createCell(2);
				cell.setCellValue(ligne.getCodePostalAvant());
				cell = row.createCell(3);
				cell.setCellValue(ligne.getCodePostalApres());
				cell = row.createCell(4);
				cell.setCellValue(ligne.getCodeCommuneAvant());
				cell = row.createCell(5);
				cell.setCellValue(ligne.getCodeCommuneApres());
				cell = row.createCell(6);
				cell.setCellValue(ligne.getLibelleAvant());
				cell = row.createCell(7);
				cell.setCellValue(ligne.getLibelleApres());
				cell = row.createCell(8);
				cell.setCellValue(ligne.getLigne5Avant());
				cell = row.createCell(9);
				cell.setCellValue(ligne.getLigne5Apres());
				compteurLigne++;
			}

			// On trace les mises a jour de code postal
			for(LigneCompteRenduHexaposte ligne: lignesMAJ){
				row = sheet.createRow(compteurLigne);
				cell = row.createCell(0);
				cell.setCellValue("Mise à jour");
				cell = row.createCell(1);
				cell.setCellValue(ligne.getIdentifiant());
				cell = row.createCell(2);
				cell.setCellValue(ligne.getCodePostalAvant());
				cell = row.createCell(3);
				cell.setCellValue(ligne.getCodePostalApres());
				cell = row.createCell(4);
				cell.setCellValue(ligne.getCodeCommuneAvant());
				cell = row.createCell(5);
				cell.setCellValue(ligne.getCodeCommuneApres());
				cell = row.createCell(6);
				cell.setCellValue(ligne.getLibelleAvant());
				cell = row.createCell(7);
				cell.setCellValue(ligne.getLibelleApres());
				cell = row.createCell(8);
				cell.setCellValue(ligne.getLigne5Avant());
				cell = row.createCell(9);
				cell.setCellValue(ligne.getLigne5Apres());
				compteurLigne++;
			}

			// On trace la cloture de code postal
			for(LigneCompteRenduHexaposte ligne: lignesCloturees){
				row = sheet.createRow(compteurLigne);
				cell = row.createCell(0);
				cell.setCellValue("Clôture");
				cell = row.createCell(1);
				cell.setCellValue(ligne.getIdentifiant());
				cell = row.createCell(2);
				cell.setCellValue(ligne.getCodePostalAvant());
				cell = row.createCell(3);
				cell.setCellValue(ligne.getCodePostalApres());
				cell = row.createCell(4);
				cell.setCellValue(ligne.getCodeCommuneAvant());
				cell = row.createCell(5);
				cell.setCellValue(ligne.getCodeCommuneApres());
				cell = row.createCell(6);
				cell.setCellValue(ligne.getLibelleAvant());
				cell = row.createCell(7);
				cell.setCellValue(ligne.getLibelleApres());
				cell = row.createCell(8);
				cell.setCellValue(ligne.getLigne5Avant());
				cell = row.createCell(9);
				cell.setCellValue(ligne.getLigne5Apres());
				compteurLigne++;
			}

			workbook.write(fluxMemoire);

			return fluxMemoire.toByteArray();
		} catch (IOException e) {
			throw new BusinessServiceException(e);
		}


	}

	@Override
	@Transactional
	public boolean hasNombreDeLignesSuffisant(InputStream fluxFichier) throws BusinessServiceException {
		try {
			int nombreLignes = 0;
			InputStreamReader inputStreamReader = new InputStreamReader(fluxFichier);
			BufferedReader fileInputStream = new BufferedReader(inputStreamReader);
			while(fileInputStream.readLine()!=null){
				nombreLignes++;
			}
			TaParametrage enregistrementParametrage = (TaParametrage) editTablesPersistanceService.findById(TaParametrage.class, "LIGNES_HEX");
			int nombreLignesMinimum = Integer.parseInt(enregistrementParametrage.getValeur());
			return nombreLignes > nombreLignesMinimum;
		} catch (IOException e){
			throw new BusinessServiceException(e);
		}

	}


}
