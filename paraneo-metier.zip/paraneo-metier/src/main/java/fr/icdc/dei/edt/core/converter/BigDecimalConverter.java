package fr.icdc.dei.edt.core.converter;

import java.math.BigDecimal;

public class BigDecimalConverter implements Converter {

	private static final String CONVERSION_MESSAGE_ID = "edittables.converter.BigDecimalConverter";
	
	public BigDecimalConverter() {
	}

	public Object getAsObject(String value) throws ConverterException {

		if (value != null) {
			{
				value = value.trim();
				if (value.length() > 0) {
					try {
						return new BigDecimal(value.trim());
					} catch (NumberFormatException e) {
						throw new ConverterException(CONVERSION_MESSAGE_ID, e);
					}
				}
			}
		}
		return null;
	}

	public String getAsString(Object value) throws ConverterException {

		if (value == null) {
			return "";
		}
		if (value instanceof String) {
			return (String) value;
		}
		return ((BigDecimal) value).toString();
	}
	
	private String label;
	
	public void setLabel(String label) {
		this.label = label;	
	}
}
