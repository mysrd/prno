package fr.icdc.dei.lm4.paraneo.entite.transverse;

public enum ChampsValidables501 {
	CNPAYA,
	CPAYI2;
}
