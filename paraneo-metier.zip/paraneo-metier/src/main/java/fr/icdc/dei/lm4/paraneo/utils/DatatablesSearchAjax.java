package fr.icdc.dei.lm4.paraneo.utils;

public class DatatablesSearchAjax {
	private String value;
	
	private boolean regex;

	public String getValue() {
		return value;
	}

	public void setValue(String search) {
		this.value = search;
	}

	public boolean isRegex() {
		return regex;
	}

	public void setRegex(boolean regex) {
		this.regex = regex;
	}
	
	
}
