package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDatesEffetDeviseValidator implements ConstraintValidator<ValidDatesEffetDevise, Object>{

	@Override
	public void initialize(ValidDatesEffetDevise constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if(value instanceof HorodatageEffetDevise){
			HorodatageEffetDevise valeurCastee = (HorodatageEffetDevise) value;
			Date dateDebutEffetDevise = valeurCastee.getYddedv();
			Date dateFinEffetDevise = valeurCastee.getYdfedv();
			if (dateDebutEffetDevise.after(dateFinEffetDevise)){
				return false;
			}
			else{
				return true;
			}
		}
		return false;
	}
}
