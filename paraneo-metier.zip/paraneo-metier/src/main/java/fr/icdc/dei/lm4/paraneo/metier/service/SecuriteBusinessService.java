package fr.icdc.dei.lm4.paraneo.metier.service;

import java.util.List;

/**
 * Service permettant d'obtenir les droits de l'utilisateur pour l'utilisation des tables
 * @author porsini
 *
 */
public interface SecuriteBusinessService {

	/**
	 * Retourne les tables accessibles a l'utilisateur en consultation
	 * @return
	 */
	public List<String> verifierAccesConsultation();


	/**
	 * Retourne les tables accessibles a l'utilisateur en modification
	 * @return
	 */
	public List<String> verifierAccesModification();

	public List<String> verifierAccesCreation();

	public List<String> verifierAccessSuppression();

	public List<String> verifierAccessNotification();

}
