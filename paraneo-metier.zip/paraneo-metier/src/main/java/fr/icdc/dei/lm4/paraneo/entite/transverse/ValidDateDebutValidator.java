package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidDateDebutValidator implements ConstraintValidator<ValidDateDebut, Object> {

	@Override
	public void initialize(ValidDateDebut constraintAnnotation) { }

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if (value instanceof HorodatageDebut) {
			HorodatageDebut h = (HorodatageDebut) value;
			Date dateDebut = h.getYdde();
			Date dateFin;
			
			// datefin est facultatif, possibilité de catch un null
			try {
				dateFin = h.getYdfe();				
			} catch (NullPointerException ex) {
				return true;
			}
			
			if (dateFin == null)
				return true;
			
			if (dateDebut.after(dateFin)) // si datedebut > datefin on retourne faux
				return false;
			else
				return true; // sinon on retourne vrai
		}
		return false;
	}

}
