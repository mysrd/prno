package fr.icdc.dei.lm4.paraneo.dao;

import java.util.List;

import fr.icdc.dei.lm4.paraneo.critere.CritereRechercheMenu;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;

/**
 * @author adhieb-e
 *
 */
public interface MenuDAO extends AbstractDAO<Menu, String> {

	/**
	 * @param critere l'habilitation et la structure de l'utilisateur connecte
	 * @return le menu auquel l'utilisateur a droit
	 */
	public List<Menu> buildMenus(CritereRechercheMenu critere);
}
