package fr.icdc.dei.lm4.paraneo.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;

/**
 * Fournit un ensemble de methodes pour gerer l'introspection
 * @author porsini
 *
 */
public class IntrospectionUtils {
	private static final Logger LOGGER = Logger.getLogger(IntrospectionUtils.class);
	/**
	 * <p>Fait la correspondance entre un nom de table et un objet TableDescription</p>
	 * @param descriptionsTable
	 * @param nomTable
	 * @return Retourne l'objet TableDescription correspondant au nom de table fourni, retourne null si pas de correspondance
	 */
	public static TableDescription getTableDescriptionFromTableName(List<TableDescription> descriptionsTable, String nomTable){
		List<TableDescription> correspondances = new ArrayList<>();
		for (TableDescription descriptionTable : descriptionsTable) {
			if(descriptionTable.getTableName().toLowerCase().contains(nomTable.toLowerCase()) || descriptionTable.getTableName().replace("_","").toLowerCase().contains(nomTable.toLowerCase())){
				correspondances.add(descriptionTable);
			}
		}

		if(correspondances.size()>1){
			boolean isTableHistorique = nomTable.contains("historique");
			for (TableDescription tableDescription : correspondances) {
				if(isTableHistorique && tableDescription.getTableName().toLowerCase().contains("historique")){
					return tableDescription;
				} else if(!isTableHistorique && !tableDescription.getTableName().toLowerCase().contains("historique")){
					return tableDescription;
				}
			}
		} else if (correspondances.size()==1) {
			return correspondances.get(0);
		}
		return null;


	}

	public static String getClassNameFromTableName(List<TableDescription> descriptionsTable, String nomTable){
		TableDescription tableDescriptionFromTableName = getTableDescriptionFromTableName(descriptionsTable, nomTable);
		return tableDescriptionFromTableName!=null?tableDescriptionFromTableName.getEntityClassName():null;
	}
	
	/**
	 * <p>Recupere l'entite Hibernate a partir d'un objet TableDescription</p>
	 * @param descriptionTable
	 * @return l'entite hibernate
	 * @throws BusinessServiceException Si l'entite n'est pas trouvee dans le projet lance une businessServiceException
	 */
	public static Class<?> getEntiteFromTableDescription(TableDescription descriptionTable) throws BusinessServiceException{
		try {
			Class<?> entite = Class.forName(descriptionTable.getEntityClassName());
			return entite;
		} catch (ClassNotFoundException e) {
			throw new BusinessServiceException(e);
		}
	}
	
	
	public static Class<?> getEntite(String tableARecuperer, List<TableDescription> listeDesTables) throws BusinessServiceException {
		String nomDeLentite = IntrospectionUtils.getClassNameFromTableName(listeDesTables, tableARecuperer);

		// On retourne la clef primaire sous forme de String
		try {
			Class<?> classeEntite = Class.forName(nomDeLentite);
			return classeEntite;
		} catch(ClassNotFoundException e){
			throw new BusinessServiceException("Table non gérée par l'application"); // NOSONAR
		}
	}
	
	public static void reorderColumns(TableDescription table, List<String> ordreDesColonnes){
		List<ColumnDescription> listeNonTriee = table.getColumnList();
		List<ColumnDescription> listeTriee = new ArrayList<>();
		for (String nomColonne : ordreDesColonnes) {
			for (ColumnDescription columnDescription : listeNonTriee) {
				if(columnDescription.getColumnName().equals(nomColonne)){
					listeTriee.add(columnDescription);
				}
			}

		}
		table.setColumnList(listeTriee);


	}
	
	/**
	 * Retourne le nom et la valeur des clefs primaires de l'objet fourni
	 * Les clefs sont au format Hibernate champ1.champ2
	 * @param value
	 * @param description
	 * @return
	 */
	public static Map<String,Object> getPrimaryKeysNameAndValues(Object value, TableDescription description) throws BusinessServiceException{
		List<ColumnDescription> listeColonnes = description.getColumnList();
		List<String> clefsPrimaireFormatJava = new ArrayList<String>();
		Map<String,Object> resultat = new HashMap<String, Object>();
		
		try {
			Class<?> classe = Class.forName(description.getEntityClassName());
			
			// On trouve toutes les clefs primaires de l'objet
			for (ColumnDescription colonne : listeColonnes) {
				if(colonne.isPrimaryKey()){
					if(colonne.isForeignKey()){
						clefsPrimaireFormatJava.add((colonne.getPropertyName()+"#"+colonne.getColumnName().toLowerCase()));
					} else {
						clefsPrimaireFormatJava.add(colonne.getColumnName().toLowerCase());
					}
				}
			}
	
			// On trouve la valeur de chaque clef primaire
			for (String clefPrimaire : clefsPrimaireFormatJava) {
				if(clefPrimaire.contains("#")){
					String[] composantsClefs = StringUtils.split(clefPrimaire,"#");
					Field champ = classe.getDeclaredField(composantsClefs[0]);
					champ.setAccessible(true);
					Object tableEtrangere = champ.get(value);
					Class<?> classeTableEtrangere = tableEtrangere.getClass();
					Field champTableEtrangere = classeTableEtrangere.getDeclaredField(composantsClefs[1]);
					champTableEtrangere.setAccessible(true);
					resultat.put(clefPrimaire.replace("#", "."), (String)champTableEtrangere.get(tableEtrangere)); // On remplace les dieses par le separateur hibernate
				} else {
					Field champ = classe.getDeclaredField(clefPrimaire);
					champ.setAccessible(true);
					Object valeurChamp = champ.get(value);
					resultat.put(clefPrimaire, valeurChamp);
				}
			}
			// On retourne une map avec pour clef le champ et pour valeur la valeur du champ	
			return resultat;
		} catch(ClassNotFoundException | NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e){
			throw new BusinessServiceException(e);
		}
	}


	public static List<String> getForeignKeysName(TableDescription description) {
		List<ColumnDescription> listeColonnes = description.getColumnList();
		List<String> clefsPrimaireFormatJava = new ArrayList<String>();

			// On trouve toutes les clefs primaires de l'objet
			for (ColumnDescription colonne : listeColonnes) {
					if(colonne.isForeignKey()){
						clefsPrimaireFormatJava.add((colonne.getPropertyName()));//+"."+colonne.getColumnName().toLowerCase()));
					}
			}
		return clefsPrimaireFormatJava;
	}

}
