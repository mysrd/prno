package fr.icdc.dei.lm4.paraneo.utils;

/**
 * Represente les informations relatives a une colonne de table telles qu'envoyees par l'appel Ajax datatables
 * @author porsini
 *
 */
public class DatatablesColumnAjax {
	private Integer index;
	private String data;
	private String name;
	private boolean searchable;
	private boolean orderable;
	private String orderDirection;
	private String searchValue;
	private boolean searchRegex;
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isSearchable() {
		return searchable;
	}
	public void setSearchable(boolean searchable) {
		this.searchable = searchable;
	}
	public boolean isOrderable() {
		return orderable;
	}
	public void setOrderable(boolean orderable) {
		this.orderable = orderable;
	}
	public String getOrderDirection() {
		return orderDirection;
	}
	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}
	public String getSearchValue() {
		return searchValue;
	}
	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}
	public boolean isSearchRegex() {
		return searchRegex;
	}
	public void setSearchRegex(boolean searchRegex) {
		this.searchRegex = searchRegex;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((index == null) ? 0 : index.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj){
			return true;
		}
		if (obj == null){
			return false;
		}
		if (getClass() != obj.getClass()){
			return false;
		}
		DatatablesColumnAjax other = (DatatablesColumnAjax) obj;
		if (index == null) {
			if (other.index != null){
				return false;
			}
		} else if (!index.equals(other.index)){
			return false;
		}
		return true;
	}
	@Override
	public String toString() {
		return "DatatablesColumnAjax [index=" + index + ", data=" + data
				+ ", name=" + name + ", searchable=" + searchable
				+ ", orderable=" + orderable + ", orderDirection="
				+ orderDirection + ", searchValue=" + searchValue
				+ ", searchRegex=" + searchRegex + "]";
	}





}
