package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

public abstract class HorodatageOuvertureFermeture extends Horodatage {

	public abstract Date getYdo000();

	public abstract void setYdo000(Date ydo000);

	public abstract Date getYdf000();

	public abstract void setYdf000(Date ydf000);

	//public abstract char getCtmaj1();

	//public abstract void setCtmaj1(char ctmaj1);

	public void initialiserDateOuverture(){
		this.setYdo000(Calendar.getInstance().getTime());
	}

	public void initialiserDateFermeture(){
		this.setYdf000(ParaneoUtils.obtenirDateMaximum());
	}

	//public void initialiserTypeMaj(){
	//	this.setCtmaj1('C');
	//}

	public boolean controleCoherenceDates(){
		if(this.getYdo000().after(getYdf000())){
			return false;
		}
		else{
			return true;
		}
	}

	@XmlElement(name="ydo000")
	public String getDateOuverturetWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdo000());

	}

	@XmlElement(name="ydf000")
	public String getDateFermetureWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdf000());

	}

}
