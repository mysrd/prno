package fr.icdc.dei.lm4.paraneo.entite.transverse;

public class LigneHexaposte {

	private String identifiant;
	
	private String codeINSEE;
	
	private String libelle;
	
	private String indicateurDePluridistribution;
	
	private String typeCodePostal;
	
	private String libelleLigne5;
	
	private String codePostal;
	
	private String libelleAcheminement;
	
	private String codeINSEEAncienneCommune;
	
	private String codeDeMiseAJour;
	
	private String CEA;

	public String getIdentifiant() {
		return identifiant;
	}

	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}

	public String getCodeINSEE() {
		return codeINSEE;
	}

	public void setCodeINSEE(String codeINSEE) {
		this.codeINSEE = codeINSEE;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getIndicateurDePluridistribution() {
		return indicateurDePluridistribution;
	}

	public void setIndicateurDePluridistribution(
			String indicateurDePluridistribution) {
		this.indicateurDePluridistribution = indicateurDePluridistribution;
	}

	public String getTypeCodePostal() {
		return typeCodePostal;
	}

	public void setTypeCodePostal(String typeCodePostal) {
		this.typeCodePostal = typeCodePostal;
	}

	public String getLibelleLigne5() {
		return libelleLigne5;
	}

	public void setLibelleLigne5(String libelleLigne5) {
		this.libelleLigne5 = libelleLigne5;
	}

	public String getCodePostal() {
		return codePostal;
	}

	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}

	public String getLibelleAcheminement() {
		return libelleAcheminement;
	}

	public void setLibelleAcheminement(String libelleAcheminement) {
		this.libelleAcheminement = libelleAcheminement;
	}

	public String getCodeINSEEAncienneCommune() {
		return codeINSEEAncienneCommune;
	}

	public void setCodeINSEEAncienneCommune(String codeINSEEAncienneCommune) {
		this.codeINSEEAncienneCommune = codeINSEEAncienneCommune;
	}

	public String getCodeDeMiseAJour() {
		return codeDeMiseAJour;
	}

	public void setCodeDeMiseAJour(String codeDeMiseAJour) {
		this.codeDeMiseAJour = codeDeMiseAJour;
	}

	public String getCEA() {
		return CEA;
	}

	public void setCEA(String cEA) {
		CEA = cEA;
	}
	
	
}
