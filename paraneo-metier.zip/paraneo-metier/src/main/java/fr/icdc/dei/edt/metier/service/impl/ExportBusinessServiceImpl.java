package fr.icdc.dei.edt.metier.service.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.supercsv.io.ICsvBeanWriter;

import fr.icdc.dei.edt.core.description.ColumnDescription;
import fr.icdc.dei.edt.core.description.TableDescription;
import fr.icdc.dei.edt.metier.service.ExportBusinessService;
import fr.icdc.dei.edt.metier.service.ReferentielBusinessService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaLibelleColonneTable;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.utils.IntrospectionUtils;

@Service("exportBusinessService")
public class ExportBusinessServiceImpl implements ExportBusinessService {

	@Resource(name = "editTablesBusinessService")
	private ReferentielBusinessService referentielBS;
	
	@Override
	public void ecrireFichier(ICsvBeanWriter writer, Map<String, Object> model) throws IOException, BusinessServiceException {
		// On recupere le nom de la table a exporter
		String nomTable = (String) model.get("NOM_TABLE");
		// On recupere tous les enregistrements de la table
		List<TableDescription> tableList = referentielBS.getTableList();
		Class<?> classe = IntrospectionUtils.getEntite(nomTable.replace("_", ""), tableList);
		List<Object> enregistrements = referentielBS.findAll(classe.getName());

		TableDescription tableDescription = IntrospectionUtils.getTableDescriptionFromTableName(tableList, nomTable);
		IntrospectionUtils.reorderColumns(tableDescription, referentielBS.getColumnsOrder(tableDescription));
		List<TaLibelleColonneTable> allLibelleColonneTable = referentielBS.getAllLibelleColonneTable();
		Map<String,String> enTetesCodeEtLibelle = obtenirCorrespondanceCodeLibelle(allLibelleColonneTable, tableDescription);
		List<String> enTetesCode = new ArrayList<String>(enTetesCodeEtLibelle.keySet());
		
		// On utilise Super CSV pour generer le fichier
		
		// Premiere ligne d'en tete
		writer.writeHeader(enTetesCode.toArray(new String[0]));
		
		// Seconde ligne d'en tete
		//writer.write(enTetesCodeEtLibelle.values().toArray(new String[0]),enTetesCode.toArray(new String[0]));
		writer.writeHeader(enTetesCodeEtLibelle.values().toArray(new String[0]));
		
		for (Object enregistrement : enregistrements) {
			writer.write(enregistrement, enTetesCode.toArray(new String[0]));
		}

	}

	@Override
	public Map<String, String> obtenirCorrespondanceCodeLibelle(List<TaLibelleColonneTable> libelles,TableDescription descriptionTable) {
		Map<String,String> correspondance = new LinkedHashMap<String, String>();
		for (ColumnDescription descriptionColonne : descriptionTable.getColumnList()) {
			correspondance.put(descriptionColonne.getColumnName(), "");
			for (TaLibelleColonneTable libelle : libelles) {
				if(descriptionColonne.getColumnName().equals(libelle.getCodColonne())){
					correspondance.put(descriptionColonne.getColumnName(),libelle.getLibColonne());		
				}					
			}
		}
		
		
		return correspondance;
	}
	


}
