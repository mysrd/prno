package fr.icdc.dei.lm4.paraneo.utils;

import org.hibernate.sql.JoinType;


/** Utilisé pour créer des alias en Criteria, fait le lien entre le service et
 *  le DAO
 */
public final class Alias {

	/** Chemin de l'association dans l'entité, séparé par un point **/
	private String associationPath;

	/** Alias assigné à l'association **/
	private String aliasAssociation;

	private JoinType joinType;

	public Alias(String associationPath, String alias){
		this.setAssociationPath(associationPath);
		this.setAlias(alias);
	}

	public Alias(String associationPath, String alias, JoinType joinType) {
		this.setAssociationPath(associationPath);
		this.setAlias(alias);
		this.setJoinType(joinType);
	}

	public void setAssociationPath(String associationPath) {
		this.associationPath = associationPath;
	}

	public String getAssociationPath() {
		return associationPath;
	}

	public void setAlias(String alias) {
		this.aliasAssociation = alias;
	}

	public String getAlias() {
		return aliasAssociation;
	}

	/**
	 * @return the joinType
	 */
	public JoinType getJoinType() {
		return joinType;
	}

	/**
	 * @param joinType the joinType to set
	 */
	public void setJoinType(JoinType joinType) {
		this.joinType = joinType;
	}

}
