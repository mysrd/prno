package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.util.Date;

public abstract class TableHistorique {
	public void initTableHistorique(Object enregistrement, String loginUser) {
		this.setAction("D");
		this.setHorodatage(new Date());
		this.setCusersuppression(loginUser);
		if(enregistrement instanceof Horodatage){
			Horodatage enregistrementCaste = (Horodatage) enregistrement;
			this.setYdc000(enregistrementCaste.getYdc000());
			this.setCuser(enregistrementCaste.getCuser());
		} else if (enregistrement instanceof HorodatageCalendrier){
			HorodatageCalendrier enregistrementCaste = (HorodatageCalendrier) enregistrement;
			this.setYdc000(enregistrementCaste.getYdc000());
			this.setCuser(enregistrementCaste.getCuser());

		}
		this.initChampsSpecifiques(enregistrement);

	}

	public abstract Date getHorodatage();
	public abstract void setHorodatage(Date date);
	public abstract String getAction();
	public abstract void setAction(String action);
	public abstract Date getYdc000();
	public abstract void setYdc000(Date ydc000);
	public abstract String getCuser();
	public abstract void setCuser(String cuser);
	public abstract String getCusersuppression();
	public abstract void setCusersuppression(String cusersuppression);

	protected abstract void initChampsSpecifiques(Object enregistrement);
}