package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidAnneeValidator implements ConstraintValidator<ValidAnnee, String> {

	private int min;
	private int max;
	
	@Override
	public void initialize(ValidAnnee validAnnee) {
		this.min = validAnnee.minAnnee();
		this.max = validAnnee.maxAnnee();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if (value.length() != 4)
			return false;

		try {
			int year = Integer.valueOf(value);
			
			if (year < min || year > max)
				return false;

			return true;
		} catch (NumberFormatException ex) {
			return false;
		}
	}

}
