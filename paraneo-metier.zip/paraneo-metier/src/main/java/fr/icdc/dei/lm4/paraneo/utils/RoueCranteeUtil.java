package fr.icdc.dei.lm4.paraneo.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component("roueCranteeUtil")
public class RoueCranteeUtil {
	private static final String CSS_EXPORTER = "exportXcel exportTableButton";
	private static final String CSS_INSERER = "ajouter ajoutTableButton";
	private static final String CSS_CONSULTER = "consulter consultationTableButton";
	private static final String CSS_MODIFIER = "modifier editerEnregistrementButton";
	private static final String CSS_SUPPRIMER = "supprimer supprimerEnregistrementButton";
	
	private static final String PREFIXE_LIEN_EXPORTER = "roue_insertion_";
	private static final String PREFIXE_LIEN_CONSULTER = "roue_consultation_";
	private static final String PREFIXE_LIEN_INSERER = "roue_insertion_";
	
	
	private static final String CLEF_MESSAGE_INSERER = "paraneo.rouecrantee.inserer";
	private static final String CLEF_MESSAGE_CONSULTER = "paraneo.rouecrantee.consulter";
	private static final String CLEF_MESSAGE_EXPORTER = "paraneo.rouecrantee.exporter";
	private static final String CLEF_MESSAGE_MODIFIER = "paraneo.rouecrantee.modifier";
	private static final String CLEF_MESSAGE_SUPPRIMER = "paraneo.rouecrantee.supprimer";
		
	@Autowired
	private LocalizationUtil localizationUtil;
	
	public void ajouterBoutonSupprimer(String hdivUrl, StringBuilder sb) {
		ajouterBoutonDetailsTable(hdivUrl, sb, CSS_SUPPRIMER, localizationUtil.obtenirLibelle(CLEF_MESSAGE_SUPPRIMER));
	}

	public void ajouterBoutonEditer(String hdivUrl, StringBuilder sb) {
		ajouterBoutonDetailsTable(hdivUrl, sb, CSS_MODIFIER, localizationUtil.obtenirLibelle(CLEF_MESSAGE_MODIFIER));
	}
	
	private void ajouterBoutonDetailsTable(String hdivUrl, StringBuilder sb, String classesCSS, String libelle){
		sb.append("<li>");
		sb.append("<a class=\"menu-action icone "+classesCSS+"\" href=\""+hdivUrl+"\" lien=\""+hdivUrl+"\" data-index=\"0\">"+libelle+"</a>");
		sb.append("</li>");		
	}

	
	public void ajouterBoutonConsulter(String hdivUrl, StringBuilder sb, String nomTable) {
		ajouterBoutonListeDesTables(hdivUrl, sb, nomTable, CSS_CONSULTER, localizationUtil.obtenirLibelle(CLEF_MESSAGE_CONSULTER),PREFIXE_LIEN_CONSULTER);
	}

	public void ajouterBoutonInserer(String hdivUrl, StringBuilder sb, String nomTable) {
		ajouterBoutonListeDesTables(hdivUrl, sb, nomTable, CSS_INSERER, localizationUtil.obtenirLibelle(CLEF_MESSAGE_INSERER),PREFIXE_LIEN_INSERER);
	}

	public void ajouterBoutonExporter(String hdivUrl, StringBuilder sb, String nomTable) {
		ajouterBoutonListeDesTables(hdivUrl, sb, nomTable, CSS_EXPORTER, localizationUtil.obtenirLibelle(CLEF_MESSAGE_EXPORTER),PREFIXE_LIEN_EXPORTER);
	}
	
	private void ajouterBoutonListeDesTables(String hdivUrl, StringBuilder sb, String nomTable, String classesCSS, String libelle, String prefixe){
		sb.append("<li>");
		sb.append("<a class=\"menu-action icone "+classesCSS+"\" id=\""+prefixe+nomTable+"\" href=\""+hdivUrl+"\" lien=\""+hdivUrl+"\" data-index=\"0\">"+libelle+"</a>");
		sb.append("</li>");
		
	}
	
}
