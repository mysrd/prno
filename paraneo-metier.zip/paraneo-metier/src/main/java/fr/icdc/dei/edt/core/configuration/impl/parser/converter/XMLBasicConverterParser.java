package fr.icdc.dei.edt.core.configuration.impl.parser.converter;

import org.dom4j.Node;

import fr.icdc.dei.edt.core.configuration.parser.converter.BasicConverterParser;

public class XMLBasicConverterParser implements BasicConverterParser {

	private final Node converterNode;
	
	public XMLBasicConverterParser(Node converterNode) {
		this.converterNode = converterNode;
	}
	
	public String getClassName() {
		return converterNode.valueOf("@className");
	}

	public String getId() {
		return converterNode.valueOf("@id");
	}

}
