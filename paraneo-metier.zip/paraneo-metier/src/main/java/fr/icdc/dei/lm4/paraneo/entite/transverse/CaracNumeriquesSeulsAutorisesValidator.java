package fr.icdc.dei.lm4.paraneo.entite.transverse;
import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Verifie que le string est compose uniquement des caracteres numeriques quelle que soit la zone de saisie
 * @author porsini
 *
 */
public class CaracNumeriquesSeulsAutorisesValidator implements ConstraintValidator<CaracNumeriquesSeulsAutorises, String> {

	@Override
	public void initialize(CaracNumeriquesSeulsAutorises constraintAnnotation) {
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
        List<Character> valeursAutorisees = new ArrayList<>();
        valeursAutorisees.add('0');
        valeursAutorisees.add('1');
        valeursAutorisees.add('2');
        valeursAutorisees.add('3');
        valeursAutorisees.add('4');
        valeursAutorisees.add('5');
        valeursAutorisees.add('6');
        valeursAutorisees.add('7');
        valeursAutorisees.add('8');
        valeursAutorisees.add('9');

		for (int i = 0; i < value.length(); i++) {
            if(!valeursAutorisees.contains(value.charAt(i))){
				return false;
			}
		}
		return true;
	}

}
