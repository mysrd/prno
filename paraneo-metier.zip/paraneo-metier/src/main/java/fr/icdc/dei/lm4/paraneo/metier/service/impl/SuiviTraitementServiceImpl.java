package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.edt.persistance.service.GenericPersistenceService;
import fr.icdc.dei.lm4.paraneo.entite.transverse.TaSuiviTraitement;
import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.EtatTraitement;
import fr.icdc.dei.lm4.paraneo.metier.service.SuiviTraitementService;

@Service("suiviTraitementService")
public class SuiviTraitementServiceImpl implements SuiviTraitementService {
	
	@Autowired
	private GenericPersistenceService editTablesPersistanceService;

	private static final Logger LOGGER = Logger.getLogger(SuiviTraitementServiceImpl.class);

	@Transactional
	public Integer signalerDebutTraitement(String codeTraitement, String empreinte) throws BusinessServiceException{
		TaSuiviTraitement nouvelEnregistrement = new TaSuiviTraitement();
		nouvelEnregistrement.setCodeTraitement(codeTraitement);
		nouvelEnregistrement.setDateDebut(new Date());
		nouvelEnregistrement.setEmpreinte(empreinte);
		
		editTablesPersistanceService.create(nouvelEnregistrement);
		LOGGER.debug("Création d'un nouvel enregistrement pour le traitement "+codeTraitement+" avec pour identifiant "+nouvelEnregistrement.getIdentifiantTraitement());
		return nouvelEnregistrement.getIdentifiantTraitement();
	}
	
	@Transactional
	public void signalerFinTraitement(String codeTraitement, Integer identifiantTraitement, EtatTraitement etatTraitement) throws BusinessServiceException{
		TaSuiviTraitement enregistrementExistant = (TaSuiviTraitement) editTablesPersistanceService.findById(TaSuiviTraitement.class, identifiantTraitement);
		enregistrementExistant.setDateFin(new Date());
		enregistrementExistant.setEtatTraitement(etatTraitement.getValeur());
		editTablesPersistanceService.update(enregistrementExistant);
		LOGGER.debug("Mise à jour d'un enregistrement pour le traitement "+codeTraitement+" avec pour date de fin "+enregistrementExistant.getDateFin());

	}
	
	@Transactional
	public boolean isTraitementEnCours(String codeTraitement) throws BusinessServiceException{
		List<String> clefs = new ArrayList<String>();
		List<Object> valeurs = new ArrayList<Object>();
		clefs.add("codeTraitement");
		valeurs.add(codeTraitement);
		clefs.add("dateFin");
		valeurs.add(null);
		TaSuiviTraitement enregistrementExistant = (TaSuiviTraitement) editTablesPersistanceService.findByMultiCriteria(TaSuiviTraitement.class, clefs, valeurs);
		LOGGER.debug("Vérification que le traitement "+codeTraitement+" n'est pas en cours d'exécution");
		return enregistrementExistant != null;
	}

	@Transactional
	public boolean isEmpreinteDejaTraitee(String codeTraitement, String empreinte) {
		List<String> clefs = new ArrayList<String>();
		List<Object> valeurs = new ArrayList<Object>();
		clefs.add("codeTraitement");
		valeurs.add(codeTraitement);
		clefs.add("etatTraitement");
		valeurs.add(EtatTraitement.OK.getValeur());
		clefs.add("empreinte");
		valeurs.add(empreinte);
		
		TaSuiviTraitement enregistrementExistant = (TaSuiviTraitement) editTablesPersistanceService.findByMultiCriteria(TaSuiviTraitement.class, clefs, valeurs);
		LOGGER.debug("Vérification que l'empreinte "+empreinte+" n'est pas déjà traitée");
		return enregistrementExistant != null;	
	}

}
