package fr.icdc.dei.lm4.paraneo.entite.transverse;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
* Verifie que l'entier est compose uniquement des caracteres autorises quelle que soit la zone de saisie
* @author porsini
*
*/
public class CaracAutorisesEntierCasGeneralValidator implements ConstraintValidator<CaracAutorisesEntierCasGeneral, String> {

	private int nbCarac;

       @Override
       public void initialize(CaracAutorisesEntierCasGeneral constraintAnnotation) {
    	   this.nbCarac = constraintAnnotation.nbCarac();
       }

       @Override
       public boolean isValid(String value, ConstraintValidatorContext context) {

    	   if (value != null) {
    		   //value = value.trim();
    		   if (value.length() > 0) {
    			   if (value.length() != nbCarac) {
    				   return false;
    			   }
    			   for (int i = 0; i < value.length(); i++) {
//	                    if(!Character.isDigit(value.charAt(i)) && value.charAt(i)!=' '){
	                    if(!Character.isDigit(value.charAt(i))){
	                           return false;
	                    }
    			   }
    			   return true;
    		   }
    		   else{
    			   return true;
    		   }
    	   }
    	   else{
    		   return true;
    	   }
       }
}
