package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.icdc.dei.lm4.paraneo.metier.exception.BusinessServiceException;
import fr.icdc.dei.lm4.paraneo.metier.service.EtatTraitement;
import fr.icdc.dei.lm4.paraneo.metier.service.HexaposteService;
import fr.icdc.dei.lm4.paraneo.metier.service.MailService;
import fr.icdc.dei.lm4.paraneo.metier.service.SuiviTraitementService;
import fr.icdc.dei.lm4.paraneo.utils.LocalizationUtil;

@Component
public class TraitementHexaposte implements Runnable {

	private static final Logger LOGGER = Logger.getLogger(TraitementHexaposte.class);
	private InputStream fichierHexaposte;
	private String nomUtilisateur;
	private String empreinte;

	private final String NOM_TRAITEMENT = "HEXAPOSTE";

	private final String CLEF_MESSAGE_MAIL_SUCCES= "paraneo.hexaposte.mail.succes";
	private final String CLEF_MESSAGE_MAIL_ERREUR="paraneo.hexaposte.mail.erreur";
	private final String CLEF_MESSAGE_MAIL_ERREUR_GRAVE="paraneo.hexaposte.mail.erreurgrave";
	
	@Resource(name = "mailService")
	private MailService mailService;

	@Resource(name = "hexaposteBusinessService")
	private HexaposteService service;

	@Resource(name = "suiviTraitementService")
	private SuiviTraitementService suiviTraitementService;

	@Autowired
	private LocalizationUtil localizationUtil;
	

	public void setFichierHexaposte(InputStream fichierHexaposte) {
		this.fichierHexaposte = fichierHexaposte;
	}

	public void setNomUtilisateur(String nomUtilisateur) {
		this.nomUtilisateur = nomUtilisateur;
	}

	public void setEmpreinte(String empreinte) {
		this.empreinte = empreinte;
	}

	@Override
	public void run() {
		LOGGER.debug("Démarrage de traitementhexaposte");
		try {
			Integer identifiantTraitement = suiviTraitementService.signalerDebutTraitement(NOM_TRAITEMENT,empreinte);
			try {
				byte[] pieceJointe = service.lancerTraitementHexaposte(fichierHexaposte, nomUtilisateur);
				service.envoyerNotificationsDido();
				suiviTraitementService.signalerFinTraitement(NOM_TRAITEMENT, identifiantTraitement,EtatTraitement.OK);
				mailService.envoyerMailAvecPieceJointe("Traitement Hexaposte", localizationUtil.obtenirLibelle(CLEF_MESSAGE_MAIL_SUCCES),pieceJointe,genererNomPieceJointe());
				LOGGER.info("Fin correcte de traitementhexaposte");
			} catch (BusinessServiceException e) {
				suiviTraitementService.signalerFinTraitement(NOM_TRAITEMENT, identifiantTraitement,EtatTraitement.KO);
				mailService.envoyerMail("Traitement Hexaposte", localizationUtil.obtenirLibelle(CLEF_MESSAGE_MAIL_ERREUR));
				LOGGER.info("Fin en erreur de traitementhexaposte");
			}
		} catch(BusinessServiceException | RuntimeException e){ // NOSONAR
			LOGGER.error("Erreur lors du traitement Hexaposte",e);
			mailService.envoyerMail("Traitement Hexaposte", localizationUtil.obtenirLibelle(CLEF_MESSAGE_MAIL_ERREUR_GRAVE));

		}
	}

	private String genererNomPieceJointe(){
		Date dateDuJour = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd");
		return "Compte_Rendu_Hexaposte"+sdf.format(dateDuJour)+".xlsx";

	}


}
