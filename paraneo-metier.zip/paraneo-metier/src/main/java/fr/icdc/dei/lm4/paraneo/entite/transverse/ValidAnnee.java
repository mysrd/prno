package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy=ValidAnneeValidator.class)
public @interface ValidAnnee {
	
	int minAnnee() default 1970;
	int maxAnnee() default 2100;

	String message() default "{paraneo.contrainte.validannee}";

	Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
