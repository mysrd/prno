package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import fr.icdc.dei.lm4.paraneo.utils.ParaneoUtils;

/**
 * Gestion des dates pour g3p_fiche
 * @author cosiatisaf-e
 *
 */

@XmlAccessorType(XmlAccessType.NONE)
public abstract class HorodatageG3p {

	public abstract Date getYdc000();
	public abstract void setYdc000(Date ydc000);
	
	public abstract Date getYddmaj();
	public abstract void setYddmaj(Date yddmaj);
	
	public abstract Date getYdclot();
	public abstract void setYdclot(Date ydclot);
	
	// Date début effet
	public abstract Date getYddeff();
	public abstract void setYddeff(Date yddeff);
	
	// Date fin effet
	public abstract Date getYdfeff();
	public abstract void setYdfeff(Date ydfeff);
	
	// Date engagement
	public abstract Date getYden();
	public abstract void setYden(Date yden);
	
	// Date début
	public abstract Date getYdde();
	public abstract void setYdde(Date ydde);
	
	// Date fin
	public abstract Date getYdfe();
	public abstract void setYdfe(Date ydfe);
	
	public abstract String getCuser();
	public abstract void setCuser(String cuser);
	
	
	// initialiser les dates et l'utilisateur
	public void initialiserDateCreation() {
		setYdc000(Calendar.getInstance().getTime());
	}
	
	public void initialiserDateModification() {
		setYddmaj(Calendar.getInstance().getTime());
	}
	
	public void initialiserDateCloture() {
		setYdclot(ParaneoUtils.obtenirDateMaximum());
	}
	
	public void definirUtilisateur(String Cuser) {
		setCuser(Cuser);
	}
	
	public void initialiserDateDebutEffet() {
		setYddeff(Calendar.getInstance().getTime());
	}
	
	public void initialiserDateFinEffet() {
		setYdfeff(ParaneoUtils.obtenirDateMaximum());
	}
	
	
	// diffusion webservice
	@XmlElement(name="ydc000")
	public String getDateCreationWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdc000());
	}

	@XmlElement(name="ydclot")
	public String getDateClotureWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYdclot());
	}

	@XmlElement(name="yddmaj")
	public String getDateMiseAJourWebService(){
		SimpleDateFormat sdf = new SimpleDateFormat(ParaneoConstantes.FORMAT_PARAMETRES);
		return sdf.format(getYddmaj());
	}
}
