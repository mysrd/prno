package fr.icdc.dei.lm4.paraneo.critere;


import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import fr.icdc.dei.lm4.paraneo.entite.transverse.DroitsMenuEnum;

public class CritereRechercheMenu implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private List<DroitsMenuEnum> droits;
	private String structure;

	public CritereRechercheMenu() {
	}

	/**
	 * @return the droits
	 */
	public List<DroitsMenuEnum> getDroits() {
		return droits;
	}

	/**
	 * @param droits
	 *            the droits to set
	 */
	public void setDroits(List<DroitsMenuEnum> droits) {
		this.droits = droits;
	}

	/**
	 * @return the structure
	 */
	public String getStructure() {
		return structure;
	}

	/**
	 * @param structure
	 *            the structure to set
	 */
	public void setStructure(String structure) {
		this.structure = structure;
	}

	/**
	 * @param droits
	 * @param structure
	 */
	public CritereRechercheMenu(List<DroitsMenuEnum> droits, String structure) {
		super();
		this.droits = droits;
		this.structure = structure;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
