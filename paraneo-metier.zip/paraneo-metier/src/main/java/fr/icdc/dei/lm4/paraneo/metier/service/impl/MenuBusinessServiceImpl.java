package fr.icdc.dei.lm4.paraneo.metier.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import fr.icdc.dei.lm4.paraneo.critere.CritereRechercheMenu;
import fr.icdc.dei.lm4.paraneo.dao.MenuDAO;
import fr.icdc.dei.lm4.paraneo.entite.transverse.Menu;
import fr.icdc.dei.lm4.paraneo.metier.service.MenuBusinessService;


@Service("menuBusinessService")
public class MenuBusinessServiceImpl implements MenuBusinessService {

    @Resource(name = "menuDAO")
    private MenuDAO menuDAO;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    public List<Menu> construireMenus(CritereRechercheMenu critere) {


        List<Menu> listeMenuComplete = menuDAO.buildMenus(critere);

        for (Menu menuItem : listeMenuComplete) {
            menuItem.setNoeudsEnfants(new ArrayList<Menu>());
            if(menuItem.getParent()!=null){
                menuItem.getParent().setNoeudsEnfants(new ArrayList<Menu>());
            }

        }

        return listeMenuComplete;
    }


    /**
     * Methode l'intersection des ensembles de deux listes
     *
     * @param <T>
     * @param list1
     * @param list2
     * @return
     */
    public <T> List<T> intersection(List<T> list1, List<T> list2) {
        List<T> list = new ArrayList<T>();

        if(!(list1==null || list2 == null)) {
            for (T t : list1) {
                if (list2.contains(t)) {
                    list.add(t);
                }
            }
        }
        return list;
    }

}
