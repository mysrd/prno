package fr.icdc.dei.lm4.paraneo.entite.transverse;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@Constraint(validatedBy=CaracAutorisesAlphaNumAccentsValidator.class)
public @interface CaracAutorisesAlphaNumAccents {

	String message() default "{paraneo.contrainte.caracteres.autorises.alphanum.accents}";
    Class<?>[] groups() default { };
    Class<? extends Payload>[] payload() default {};
}
