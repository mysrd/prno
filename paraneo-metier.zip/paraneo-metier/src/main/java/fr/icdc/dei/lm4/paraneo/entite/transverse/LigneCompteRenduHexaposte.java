package fr.icdc.dei.lm4.paraneo.entite.transverse;

public class LigneCompteRenduHexaposte {

	private static String NON_APPLICABLE = "NA";
	private String identifiant;
	private String codePostalAvant;
	private String codePostalApres;
	private String codeCommuneAvant;
	private String codeCommuneApres;
	private String libelleAvant;
	private String libelleApres;
	private String ligne5Avant;
	private String ligne5Apres;
	
	public LigneCompteRenduHexaposte(String identifiant,
			String codePostalAvant, String codePostalApres,
			String codeCommuneAvant, String codeCommuneApres,
			String libelleAvant, String libelleApres, String ligne5Avant,
			String ligne5Apres) {
		super();
		this.identifiant = identifiant;
		this.codePostalAvant = codePostalAvant;
		this.codePostalApres = codePostalApres;
		this.codeCommuneAvant = codeCommuneAvant;
		this.codeCommuneApres = codeCommuneApres;
		this.libelleAvant = libelleAvant;
		this.libelleApres = libelleApres;
		this.ligne5Avant = ligne5Avant;
		this.ligne5Apres = ligne5Apres;
	}
	
	/**
	 * Prend la ligne du fichier et la ligne de la base en argument
	 * On alimente les champs avant avec la ligne de la base et les champs apres avec la ligne du fichier
	 * @param ligneFichier
	 * @param ligneBase
	 */
	public LigneCompteRenduHexaposte(LigneHexaposte ligneFichier, TaCodePostal ligneBase){
		this.identifiant = ligneFichier.getIdentifiant();
		
		this.codePostalAvant = ligneBase.getCodpos();
		this.codePostalApres = ligneFichier.getCodePostal();
		
		this.codeCommuneAvant = ligneBase.getCog5c();
		this.codeCommuneApres = ligneFichier.getCodeINSEE();
				
		this.libelleAvant = ligneBase.getLibcom();
		this.libelleApres = ligneFichier.getLibelle();
		
		this.ligne5Avant =ligneBase.getLibl5();
		this.ligne5Apres = ligneFichier.getLibelleLigne5();
		
	}
	
	/**
	 * Prend une ligne du fichier et ne remplit que les champs avant
	 * @param ligneFichier
	 */
	public LigneCompteRenduHexaposte(LigneHexaposte ligneFichier){
		this.identifiant = ligneFichier.getIdentifiant();
		
		this.codePostalAvant = ligneFichier.getCodePostal();
		this.codePostalApres = NON_APPLICABLE;

		this.codeCommuneAvant = ligneFichier.getCodeINSEE();
		this.codeCommuneApres = NON_APPLICABLE;

		this.libelleAvant = ligneFichier.getLibelle();
		this.libelleApres = NON_APPLICABLE;

		this.ligne5Avant = ligneFichier.getLibelleLigne5();
		this.ligne5Apres = NON_APPLICABLE;

	}
	
	public LigneCompteRenduHexaposte(TaCodePostal ligneBase){
		this.identifiant = ligneBase.getIdtl6();
		
		this.codePostalAvant = ligneBase.getCodpos();
		this.codePostalApres = NON_APPLICABLE;
		
		this.codeCommuneAvant = ligneBase.getCog5c();
		this.codeCommuneApres = NON_APPLICABLE;
				
		this.libelleAvant = ligneBase.getLibcom();
		this.libelleApres = NON_APPLICABLE;
		
		this.ligne5Avant =ligneBase.getLibl5();
		this.ligne5Apres = NON_APPLICABLE;		
	}

	public String getIdentifiant() {
		return identifiant;
	}

	public void setIdentifiant(String identifiant) {
		this.identifiant = identifiant;
	}

	public String getCodePostalAvant() {
		return codePostalAvant;
	}

	public void setCodePostalAvant(String codePostalAvant) {
		this.codePostalAvant = codePostalAvant;
	}

	public String getCodePostalApres() {
		return codePostalApres;
	}

	public void setCodePostalApres(String codePostalApres) {
		this.codePostalApres = codePostalApres;
	}

	public String getCodeCommuneAvant() {
		return codeCommuneAvant;
	}

	public void setCodeCommuneAvant(String codeCommuneAvant) {
		this.codeCommuneAvant = codeCommuneAvant;
	}

	public String getCodeCommuneApres() {
		return codeCommuneApres;
	}

	public void setCodeCommuneApres(String codeCommuneApres) {
		this.codeCommuneApres = codeCommuneApres;
	}

	public String getLibelleAvant() {
		return libelleAvant;
	}

	public void setLibelleAvant(String libelleAvant) {
		this.libelleAvant = libelleAvant;
	}

	public String getLibelleApres() {
		return libelleApres;
	}

	public void setLibelleApres(String libelleApres) {
		this.libelleApres = libelleApres;
	}

	public String getLigne5Avant() {
		return ligne5Avant;
	}

	public void setLigne5Avant(String ligne5Avant) {
		this.ligne5Avant = ligne5Avant;
	}

	public String getLigne5Apres() {
		return ligne5Apres;
	}

	public void setLigne5Apres(String ligne5Apres) {
		this.ligne5Apres = ligne5Apres;
	}
	
	
	
	
}
