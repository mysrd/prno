package fr.icdc.dei.lm4.paraneo.utils;

public class DatatablesColumn {
	private String name;
	private String title;
	private String className;
	private boolean orderable;
	private boolean searchable;
	private String type;


	public DatatablesColumn(String title) {
		super();
		this.title = title;
		this.orderable = true;
		this.searchable = true;
	}
	
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String classe) {
		this.className = classe;
	}
	public boolean isOrderable() {
		return orderable;
	}
	public void setOrderable(boolean orderable) {
		this.orderable = orderable;
	}
	public boolean isSearchable() {
		return searchable;
	}
	public void setSearchable(boolean searchable) {
		this.searchable = searchable;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}









}
