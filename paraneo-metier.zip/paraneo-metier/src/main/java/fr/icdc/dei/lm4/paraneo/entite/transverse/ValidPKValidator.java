package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidPKValidator implements ConstraintValidator<ValidPK, String> {

	private String startwith;
	private int ss;
	private String endwith;
	private int es;
	
	@Override
	public void initialize(ValidPK validpk) { 
		this.startwith = validpk.startwith();
		this.ss = validpk.startsize();
		this.endwith = validpk.endwith();
		this.es = validpk.endsize();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		// si la taille ss ou es est trop petite ou trop grande
		if (ss < 0 || ss >100 || es < 0 || es > 100) {
			return false;
		}
		
		// si on commence par des caractères alphabétiques
		if (startwith.equals("alpha")) {
			if (value.matches("^[A-Z]{" + ss + "}[0-9]{" + es + "}$")) {
				return true;
			}
			else {
				return false;
			}
		}
		
		// si on commence par des caractères numériques
		else if (startwith.equals("digit")) {
			if (value.matches("^[0-9]{" + ss + "}[A-Z]{" + es + "}$")) {
				return true;
			}
			else {
				return false;
			}
		}
		
		// sinon
		else {
			return false;
		}
	}

}
