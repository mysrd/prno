package fr.icdc.dei.edt.core.configuration.parser.converter;


public interface ConvertDateTimeParser extends ConverterParser {

	String getPattern();
	
	String getDateStyle();
	
	String getLocale();
	
	String getTimeZone();
	
	String getType();
}
