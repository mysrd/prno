package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CaracAutorisesAlphaNumOnlyValidator implements ConstraintValidator<CaracAutorisesAlphaNumOnly, String> {

	@Override
	public void initialize(CaracAutorisesAlphaNumOnly constraintAnnotation) { }

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {		
		if (value.matches("^[A-Z0-9]*$")) {
			return true;
		}
		else {
			return false;
		}
	}

}
