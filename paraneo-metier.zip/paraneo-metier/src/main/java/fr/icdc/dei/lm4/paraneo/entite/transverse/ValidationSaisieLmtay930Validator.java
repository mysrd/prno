package fr.icdc.dei.lm4.paraneo.entite.transverse;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidationSaisieLmtay930Validator implements ConstraintValidator<ValidationSaisieLmtay930, Object>{

	@Override
	public void initialize(ValidationSaisieLmtay930 constraintAnnotation) {

	}

	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		if(value instanceof TaCategorieEconomiqueLmtay930){
			TaCategorieEconomiqueLmtay930 valeurCastee = (TaCategorieEconomiqueLmtay930) value;
			String cfceco = valeurCastee.getCfceco();
			String ytopta = valeurCastee.getYtopta().trim();
			boolean cfcecoABlanc = " ".equals(cfceco);
			boolean ytoptaAOui = "O".equals(ytopta);
			boolean ytoptaANon = "N".equals(ytopta);
			if 	((ytoptaANon == true && cfcecoABlanc !=true) ||
				(ytoptaAOui == true && cfcecoABlanc == true))
{
				return false;
			}
			else{
				return true;
			}
		}
		return false;
	}

}
