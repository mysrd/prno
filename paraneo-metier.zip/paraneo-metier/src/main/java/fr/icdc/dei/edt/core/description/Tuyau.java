package fr.icdc.dei.edt.core.description;

public class Tuyau {
	private String valeur;

	public String getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
	
	
}
